package com.worldwave.radio

import com.worldwave.radio.data.Station
import com.worldwave.radio.data.cleaned
import com.worldwave.radio.util.estimateMb
import com.worldwave.radio.util.flagEmoji
import com.worldwave.radio.util.mbPerHour
import org.junit.Assert.assertEquals
import org.junit.Test

class FormatTest {
    @Test fun dataEstimate128kbpsPerHour() = assertEquals(55, mbPerHour(128))

    @Test fun unknownBitrateIsZero() = assertEquals(0.0, estimateMb(0, 600), 0.0)

    @Test fun flagForJordan() = assertEquals("\uD83C\uDDEF\uD83C\uDDF4", flagEmoji("jo"))

    @Test fun invalidCodeGetsGlobe() = assertEquals("🌐", flagEmoji("1x"))

    @Test fun cleanedRemovesDuplicatesAndBadUrls() {
        val list = listOf(
            Station("a", "Radio One", urlResolved = "http://x.com/stream"),
            Station("b", "radio one", urlResolved = "http://x.com/stream/"),
            Station("a", "Other", urlResolved = "http://y.com/live"),
            Station("c", "Bad", urlResolved = "ftp://z.com"),
            Station("d", "Good", urlResolved = "https://z.com/aac"),
        )
        assertEquals(listOf("a", "d"), list.cleaned().map { it.uuid })
    }

    @Test fun hiddenStationsAreDropped() {
        val list = listOf(Station("a", "A", urlResolved = "http://a"), Station("b", "B", urlResolved = "http://b"))
        assertEquals(listOf("b"), list.cleaned(setOf("a")).map { it.uuid })
    }
}
