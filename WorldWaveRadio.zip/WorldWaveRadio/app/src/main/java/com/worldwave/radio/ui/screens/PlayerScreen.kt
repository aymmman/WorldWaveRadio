@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.R
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.LoadContent
import com.worldwave.radio.ui.components.SectionHeader
import com.worldwave.radio.ui.components.StationArt
import com.worldwave.radio.ui.components.StationRail
import com.worldwave.radio.ui.components.TuningDial
import com.worldwave.radio.ui.components.playerStatus
import com.worldwave.radio.ui.currentLocale
import com.worldwave.radio.ui.loadable
import com.worldwave.radio.util.countryName
import com.worldwave.radio.util.flagEmoji
import com.worldwave.radio.util.formatDuration
import com.worldwave.radio.util.formatMb
import com.worldwave.radio.util.prettyLanguage
import kotlin.math.roundToInt

@Composable
fun PlayerScreen(onBack: () -> Unit) {
    val app = app()
    val actions = LocalActions.current
    val context = LocalContext.current
    val locale = currentLocale()
    val ui by app.player.state.collectAsStateWithLifecycle()
    val favorites by app.prefs.favorites.collectAsStateWithLifecycle()
    val hidden by app.prefs.hidden.collectAsStateWithLifecycle()
    var showSleep by remember { mutableStateOf(false) }

    val station = ui.station
    if (station == null) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.KeyboardArrowDown, stringResource(R.string.back)) }
            Spacer(Modifier.height(40.dp))
            Text(stringResource(R.string.nothing_playing), style = MaterialTheme.typography.titleMedium)
        }
        return
    }

    val isFav = favorites.any { it.uuid == station.uuid }
    val similar = loadable("similar", station.uuid) { app.repo.similar(station) }
    val shareText = stringResource(R.string.share_text, station.name, station.homepage.ifBlank { station.playUrl })
    val hiddenMsg = stringResource(R.string.station_hidden)
    val halo by animateFloatAsState(if (ui.isPlaying) 1f else 0f, label = "halo")
    val amber = MaterialTheme.colorScheme.primary

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = stringResource(R.string.back))
            }
            Text(
                stringResource(R.string.now_playing),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, shareText)
                }
                context.startActivity(Intent.createChooser(send, null))
            }) {
                Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.share))
            }
        }

        // Artwork with an on-air glow
        Box(Modifier.padding(top = 8.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(290.dp)
                    .graphicsLayer { alpha = halo }
                    .background(Brush.radialGradient(listOf(amber.copy(alpha = 0.32f), Color.Transparent)), CircleShape)
            )
            StationArt(station.name, station.favicon, 232.dp, corner = 36.dp)
        }

        Text(
            station.name,
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        val place = countryName(station.countryCode, station.country, locale)
        if (place.isNotBlank()) {
            Text(
                (if (station.countryCode.length == 2) flagEmoji(station.countryCode) + "  " else "") + place,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        Row(
            Modifier.padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (station.codec.isNotBlank()) Pill(station.codec)
            if (station.bitrate > 0) Pill("${station.bitrate} kbps")
            if (station.language.isNotBlank()) Pill(prettyLanguage(station.language))
        }

        TuningDial(
            seed = station.uuid,
            active = ui.isPlaying,
            modifier = Modifier.padding(horizontal = 32.dp, vertical = 18.dp),
        )

        // Status
        Text(
            playerStatus(ui),
            style = MaterialTheme.typography.bodyMedium,
            color = if (ui.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 32.dp),
        )
        if (ui.error != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                TextButton(onClick = { app.player.retry() }) { Text(stringResource(R.string.retry)) }
                TextButton(onClick = {
                    app.prefs.hide(station.uuid)
                    if (ui.hasNext) app.player.next() else app.player.stop()
                    actions.message(hiddenMsg)
                }) { Text(stringResource(R.string.hide_station)) }
            }
        }

        // Main controls
        Row(
            Modifier.padding(top = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            IconButton(onClick = { app.player.previous() }, enabled = ui.hasPrevious, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipPrevious, stringResource(R.string.previous), Modifier.size(32.dp))
            }
            Box(
                Modifier
                    .size(84.dp)
                    .clip(CircleShape)
                    .background(amber)
                    .clickable { app.player.toggle() },
                contentAlignment = Alignment.Center,
            ) {
                if (ui.isBuffering) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(36.dp),
                    )
                } else {
                    Icon(
                        if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = stringResource(if (ui.isPlaying) R.string.pause else R.string.play),
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(44.dp),
                    )
                }
            }
            IconButton(onClick = { app.player.next() }, enabled = ui.hasNext, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipNext, stringResource(R.string.next), Modifier.size(32.dp))
            }
        }

        // Secondary controls
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { app.prefs.toggleFavorite(station) }) {
                Icon(
                    if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = stringResource(if (isFav) R.string.remove_favorite else R.string.add_favorite),
                    tint = if (isFav) amber else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            val remaining = ui.sleepRemainingSec
            TextButton(onClick = { showSleep = true }) {
                Icon(Icons.Filled.Timer, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    if (remaining != null) stringResource(R.string.sleep_ends_in, formatDuration(remaining))
                    else stringResource(R.string.sleep_timer)
                )
            }
            IconButton(onClick = { app.player.stop() }) {
                Icon(Icons.Filled.Stop, contentDescription = stringResource(R.string.stop), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Session and data estimate
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    stringResource(R.string.listening_for, formatDuration(ui.sessionSeconds)),
                    style = MaterialTheme.typography.titleSmall,
                )
                val mb = ui.sessionMb
                Text(
                    if (station.bitrate > 0) stringResource(R.string.data_estimate, formatMb(mb ?: 0.0))
                    else stringResource(R.string.data_unknown),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        // Similar stations
        SectionHeader(stringResource(R.string.similar))
        LoadContent(similar, loadingHeight = 120.dp) { list ->
            val shown = list.filter { it.uuid !in hidden }
            StationRail(shown, ui, locale) { s -> actions.play(s, shown) }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showSleep) {
        SleepDialog(
            active = ui.sleepRemainingSec != null,
            onSet = { minutes ->
                app.player.setSleepTimer(minutes)
                showSleep = false
            },
            onDismiss = { showSleep = false },
        )
    }
}

@Composable
private fun Pill(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            maxLines = 1,
        )
    }
}

@Composable
private fun SleepDialog(active: Boolean, onSet: (Int?) -> Unit, onDismiss: () -> Unit) {
    var custom by remember { mutableFloatStateOf(30f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sleep_timer)) },
        text = {
            Column {
                listOf(15, 30, 45, 60, 90, 120).chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { m ->
                            FilterChip(
                                selected = false,
                                onClick = { onSet(m) },
                                label = { Text(stringResource(R.string.sleep_minutes, m)) },
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.sleep_custom, custom.roundToInt()), style = MaterialTheme.typography.bodyMedium)
                Slider(value = custom, onValueChange = { custom = it }, valueRange = 5f..180f, steps = 34)
                FilledTonalButton(onClick = { onSet(custom.roundToInt()) }) { Text(stringResource(R.string.sleep_set)) }
            }
        },
        confirmButton = {
            if (active) TextButton(onClick = { onSet(null) }) { Text(stringResource(R.string.sleep_off)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
    )
}
