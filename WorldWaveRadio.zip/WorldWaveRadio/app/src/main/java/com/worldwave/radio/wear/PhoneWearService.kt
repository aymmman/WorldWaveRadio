package com.worldwave.radio.wear

import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService
import com.worldwave.radio.RadioApp
import com.worldwave.radio.WearPaths
import com.worldwave.radio.data.Station
import com.worldwave.radio.util.NetType
import com.worldwave.radio.util.currentNetwork
import org.json.JSONObject

/** Receives remote-control commands sent from the watch. */
class PhoneWearService : WearableListenerService() {
    private val main = Handler(Looper.getMainLooper())

    override fun onMessageReceived(event: MessageEvent) {
        val path = event.path
        val payload = event.data ?: ByteArray(0)
        main.post { handle(path, payload) }
    }

    private fun handle(path: String, payload: ByteArray) {
        val app = application as RadioApp
        val player = app.player
        player.connect()
        when (path) {
            WearPaths.TOGGLE -> player.toggle()
            WearPaths.NEXT -> player.next()
            WearPaths.PREVIOUS -> player.previous()
            WearPaths.STOP -> player.stop()
            WearPaths.VOLUME_UP -> adjustVolume(AudioManager.ADJUST_RAISE)
            WearPaths.VOLUME_DOWN -> adjustVolume(AudioManager.ADJUST_LOWER)
            WearPaths.SYNC -> app.wearBridge.pushAll()
            WearPaths.PLAY -> {
                val station = try {
                    Station.fromJson(JSONObject(String(payload, Charsets.UTF_8)))
                } catch (e: Exception) {
                    null
                }
                val blocked = app.prefs.settings.value.wifiOnly && currentNetwork(this) == NetType.METERED
                if (station != null && !blocked) {
                    val favorites = app.prefs.favorites.value
                    player.play(station, if (favorites.any { it.uuid == station.uuid }) favorites else listOf(station))
                }
            }
        }
    }

    private fun adjustVolume(direction: Int) {
        val am = getSystemService(AudioManager::class.java) ?: return
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, 0)
    }
}
