package com.worldwave.radio.wear

import android.content.Context
import com.google.android.gms.wearable.PutDataMapRequest
import com.google.android.gms.wearable.Wearable
import com.worldwave.radio.WearPaths
import com.worldwave.radio.data.Prefs
import com.worldwave.radio.playback.PlayerConnection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray

/**
 * Publishes what the phone is playing, plus the favorites list, to the watch through the
 * Wear OS Data Layer. Phones without a paired watch simply get quiet failures.
 */
class WearBridge(
    private val context: Context,
    private val prefs: Prefs,
    private val player: PlayerConnection,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private data class NowPlaying(
        val uuid: String,
        val name: String,
        val country: String,
        val favicon: String,
        val playing: Boolean,
        val buffering: Boolean,
        val error: Boolean,
    )

    fun start() {
        scope.launch {
            player.state
                .map {
                    NowPlaying(
                        uuid = it.station?.uuid ?: "",
                        name = it.station?.name ?: "",
                        country = it.station?.country ?: "",
                        favicon = it.station?.favicon ?: "",
                        playing = it.isPlaying,
                        buffering = it.isBuffering,
                        error = it.error != null,
                    )
                }
                .distinctUntilChanged()
                .collect { pushState(it) }
        }
        scope.launch {
            prefs.favorites.collect { pushFavorites() }
        }
    }

    fun pushAll() {
        scope.launch {
            val s = player.state.value
            pushState(
                NowPlaying(
                    s.station?.uuid ?: "", s.station?.name ?: "", s.station?.country ?: "",
                    s.station?.favicon ?: "", s.isPlaying, s.isBuffering, s.error != null,
                )
            )
            pushFavorites()
        }
    }

    private suspend fun pushState(n: NowPlaying) = put(WearPaths.STATE) { req ->
        req.dataMap.putString("uuid", n.uuid)
        req.dataMap.putString("name", n.name)
        req.dataMap.putString("country", n.country)
        req.dataMap.putString("favicon", n.favicon)
        req.dataMap.putBoolean("playing", n.playing)
        req.dataMap.putBoolean("buffering", n.buffering)
        req.dataMap.putBoolean("error", n.error)
    }

    private suspend fun pushFavorites() {
        val arr = JSONArray()
        prefs.favorites.value.take(60).forEach { arr.put(it.toJson()) }
        put(WearPaths.FAVORITES) { req -> req.dataMap.putString("json", arr.toString()) }
    }

    private suspend fun put(path: String, fill: (PutDataMapRequest) -> Unit) {
        try {
            val req = PutDataMapRequest.create(path)
            fill(req)
            req.dataMap.putLong("ts", System.currentTimeMillis())
            Wearable.getDataClient(context).putDataItem(req.asPutDataRequest().setUrgent()).await()
        } catch (e: Exception) {
            // No watch, or Wear OS services missing on this phone. Nothing to do.
        }
    }
}
