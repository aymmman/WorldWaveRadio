package com.worldwave.radio

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.ui.AppRoot
import com.worldwave.radio.ui.theme.WorldWaveTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        val app = application as RadioApp
        setContent {
            val settings by app.prefs.settings.collectAsStateWithLifecycle()
            WorldWaveTheme(settings.theme) { AppRoot(app) }
        }
    }

    override fun onStart() {
        super.onStart()
        (application as RadioApp).player.connect()
    }
}
