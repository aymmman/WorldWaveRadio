package com.worldwave.radio.playback

import android.content.ComponentName
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import com.worldwave.radio.data.Prefs
import com.worldwave.radio.data.RadioRepository
import com.worldwave.radio.data.Station
import com.worldwave.radio.util.estimateMb
import com.worldwave.radio.util.isPlayableUrl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class PlayError { NETWORK, UNAVAILABLE, FORMAT, OTHER }

data class PlayerUi(
    val station: Station? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val error: PlayError? = null,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
    val sessionSeconds: Long = 0,
    val sessionMb: Double? = null,
    val sleepRemainingSec: Long? = null,
)

/** App-wide bridge between the UI and [RadioService]. */
class PlayerConnection(
    private val context: Context,
    private val prefs: Prefs,
    private val repo: RadioRepository,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val _state = MutableStateFlow(PlayerUi())
    val state: StateFlow<PlayerUi> = _state.asStateFlow()

    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private val known = HashMap<String, Station>()
    private val pending = ArrayList<(MediaController) -> Unit>()
    private var lastId: String? = null
    private var tickJob: Job? = null
    private var sleepJob: Job? = null
    private var pausedAt = 0L
    private var unsavedMb = 0.0

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()
    }

    init {
        registerNetworkCallback()
    }

    fun connect() {
        if (controller != null || future != null) return
        val token = SessionToken(context, ComponentName(context, RadioService::class.java))
        val f = MediaController.Builder(context, token)
            .setListener(object : MediaController.Listener {
                override fun onDisconnected(controller: MediaController) {
                    this@PlayerConnection.controller = null
                    future = null
                }
            })
            .buildAsync()
        future = f
        f.addListener({
            val c = try { f.get() } catch (e: Exception) { null }
            if (c == null) {
                future = null
                return@addListener
            }
            controller = c
            c.addListener(listener)
            sync()
            val actions = pending.toList()
            pending.clear()
            actions.forEach { it(c) }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun withController(action: (MediaController) -> Unit) {
        val c = controller
        if (c != null) action(c) else {
            pending.add(action)
            connect()
        }
    }

    fun play(station: Station, list: List<Station> = emptyList()) {
        val now = _state.value
        if (now.station?.uuid == station.uuid && (now.isPlaying || now.isBuffering)) return
        val hidden = prefs.hidden.value
        val base = if (list.any { it.uuid == station.uuid }) list else listOf(station) + list
        val clean = base.filter { it.uuid == station.uuid || it.uuid !in hidden }.distinctBy { it.uuid }
        val idx = clean.indexOfFirst { it.uuid == station.uuid }.coerceAtLeast(0)
        val from = (idx - 50).coerceAtLeast(0)
        val to = (from + 100).coerceAtMost(clean.size)
        val queue = clean.subList(from, to)
        val start = idx - from
        queue.forEach { known[it.uuid] = it }
        pausedAt = 0
        _state.update { it.copy(station = station, error = null, isBuffering = true) }
        withController { c ->
            c.setMediaItems(queue.map { it.toMediaItem() }, start, C.TIME_UNSET)
            c.volume = 1f
            c.prepare()
            c.play()
        }
    }

    fun toggle() {
        val c = controller
        if (c == null) {
            _state.value.station?.let { play(it) }
            return
        }
        if (c.isPlaying || (c.playWhenReady && c.playbackState == Player.STATE_BUFFERING)) {
            c.pause()
            pausedAt = SystemClock.elapsedRealtime()
            return
        }
        if (c.mediaItemCount == 0) {
            _state.value.station?.let { play(it) }
            return
        }
        val stale = pausedAt > 0 && SystemClock.elapsedRealtime() - pausedAt > 60_000
        if (c.playerError != null || c.playbackState == Player.STATE_IDLE ||
            c.playbackState == Player.STATE_ENDED || stale
        ) {
            // Live radio: reconnect so we resume at the live edge, not minutes behind.
            c.stop()
            c.prepare()
        }
        pausedAt = 0
        c.play()
    }

    fun retry() {
        val c = controller
        if (c == null || c.mediaItemCount == 0) {
            _state.value.station?.let { play(it) }
            return
        }
        c.stop()
        c.prepare()
        c.play()
    }

    fun stop() {
        controller?.stop()
        setSleepTimer(null)
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun previous() { controller?.seekToPreviousMediaItem() }

    fun setSleepTimer(minutes: Int?) {
        sleepJob?.cancel()
        sleepJob = null
        controller?.volume = 1f
        _state.update { it.copy(sleepRemainingSec = null) }
        if (minutes == null || minutes <= 0) return
        val end = SystemClock.elapsedRealtime() + minutes * 60_000L
        val fade = prefs.settings.value.sleepFade
        sleepJob = scope.launch {
            while (isActive) {
                val remaining = (end - SystemClock.elapsedRealtime()) / 1000
                if (remaining <= 0) break
                _state.update { it.copy(sleepRemainingSec = remaining) }
                if (fade && remaining <= 15) controller?.volume = (remaining / 15f).coerceIn(0f, 1f)
                delay(1000)
            }
            controller?.pause()
            controller?.volume = 1f
            pausedAt = SystemClock.elapsedRealtime()
            _state.update { it.copy(sleepRemainingSec = null) }
            sleepJob = null
        }
    }

    private fun sync() {
        val c = controller ?: return
        val item = c.currentMediaItem
        val station = item?.let { known[it.mediaId] ?: it.toStation() }
        val err = c.playerError?.let { classify(it) }
        val buffering = c.playWhenReady && c.playbackState == Player.STATE_BUFFERING
        _state.update {
            it.copy(
                station = station ?: it.station,
                isPlaying = c.isPlaying,
                isBuffering = buffering && err == null,
                error = err,
                hasNext = c.hasNextMediaItem(),
                hasPrevious = c.hasPreviousMediaItem(),
            )
        }
        if (station != null && station.uuid != lastId) {
            lastId = station.uuid
            flushData()
            _state.update { it.copy(sessionSeconds = 0, sessionMb = null) }
            prefs.addHistory(station)
            scope.launch { repo.registerClick(station.uuid) }
        }
        if (c.isPlaying) {
            if (tickJob == null) tickJob = scope.launch {
                while (isActive) {
                    delay(1000)
                    tick()
                }
            }
        } else {
            tickJob?.cancel()
            tickJob = null
            flushData()
        }
    }

    private fun tick() {
        val s = _state.value
        val secs = s.sessionSeconds + 1
        val br = s.station?.bitrate ?: 0
        _state.update { it.copy(sessionSeconds = secs, sessionMb = if (br > 0) estimateMb(br, secs) else null) }
        if (br > 0) {
            unsavedMb += estimateMb(br, 1)
            if (secs % 30 == 0L) flushData()
        }
    }

    private fun flushData() {
        if (unsavedMb > 0) {
            prefs.addDataUsage(unsavedMb)
            unsavedMb = 0.0
        }
    }

    private fun classify(e: PlaybackException): PlayError = when (e.errorCode) {
        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
        PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND -> PlayError.UNAVAILABLE
        PlaybackException.ERROR_CODE_TIMEOUT -> PlayError.NETWORK
        in 2000..2999 -> PlayError.NETWORK
        in 3000..4999 -> PlayError.FORMAT
        else -> PlayError.OTHER
    }

    private fun registerNetworkCallback() {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    scope.launch {
                        val c = controller ?: return@launch
                        if (c.playerError != null && c.playWhenReady && c.mediaItemCount > 0) {
                            c.seekToDefaultPosition()
                            c.prepare()
                        }
                    }
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    val metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                    if (metered && prefs.settings.value.wifiOnly) {
                        scope.launch { controller?.let { if (it.isPlaying) it.pause() } }
                    }
                }
            })
        } catch (e: Exception) {
            // Network callbacks are a nice-to-have; playback still recovers through retries.
        }
    }
}

fun Station.toMediaItem(): MediaItem {
    val requestExtras = Bundle().apply {
        putString(RadioService.EXTRA_FALLBACK, fallbackUrl)
        putBoolean(RadioService.EXTRA_HLS, hls)
    }
    val metaExtras = Bundle().apply {
        putInt("bitrate", bitrate)
        putString("codec", codec)
        putString("countryCode", countryCode)
    }
    val meta = MediaMetadata.Builder()
        .setTitle(name)
        .setDisplayTitle(name)
        .setArtist(country.ifBlank { null })
        .setArtworkUri(favicon.takeIf { isPlayableUrl(it) }?.let { Uri.parse(it) })
        .setExtras(metaExtras)
        .build()
    return MediaItem.Builder()
        .setMediaId(uuid)
        .setUri(playUrl)
        .setMediaMetadata(meta)
        .setRequestMetadata(
            MediaItem.RequestMetadata.Builder()
                .setMediaUri(Uri.parse(playUrl))
                .setExtras(requestExtras)
                .build()
        )
        .build()
}

private fun MediaItem.toStation(): Station {
    val extras = mediaMetadata.extras
    return Station(
        uuid = mediaId,
        name = mediaMetadata.title?.toString() ?: "",
        urlResolved = requestMetadata.mediaUri?.toString() ?: "",
        favicon = mediaMetadata.artworkUri?.toString() ?: "",
        country = mediaMetadata.artist?.toString() ?: "",
        countryCode = extras?.getString("countryCode") ?: "",
        codec = extras?.getString("codec") ?: "",
        bitrate = extras?.getInt("bitrate") ?: 0,
    )
}
