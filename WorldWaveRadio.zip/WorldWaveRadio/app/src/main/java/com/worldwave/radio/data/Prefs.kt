package com.worldwave.radio.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val wifiOnly: Boolean = false,
    val warnMobile: Boolean = true,
    val autoReconnect: Boolean = true,
    val sleepFade: Boolean = true,
)

/** Everything personal stays on the device, in one private SharedPreferences file. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("worldwave", Context.MODE_PRIVATE)

    private val _favorites = MutableStateFlow(readStations(K_FAV))
    val favorites: StateFlow<List<Station>> = _favorites.asStateFlow()

    private val _history = MutableStateFlow(readStations(K_HISTORY))
    val history: StateFlow<List<Station>> = _history.asStateFlow()

    private val _searches = MutableStateFlow(readStrings(K_SEARCHES))
    val searches: StateFlow<List<String>> = _searches.asStateFlow()

    private val _hidden = MutableStateFlow(readStrings(K_HIDDEN).toSet())
    val hidden: StateFlow<Set<String>> = _hidden.asStateFlow()

    private val _settings = MutableStateFlow(readSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private val _dataMb = MutableStateFlow(sp.getFloat(K_DATA, 0f).toDouble())
    val dataMb: StateFlow<Double> = _dataMb.asStateFlow()

    fun toggleFavorite(s: Station) {
        val list = _favorites.value
        val next = if (list.any { it.uuid == s.uuid }) list.filterNot { it.uuid == s.uuid } else listOf(s) + list
        _favorites.value = next
        writeStations(K_FAV, next)
    }

    fun addHistory(s: Station) {
        val next = (listOf(s) + _history.value.filterNot { it.uuid == s.uuid }).take(60)
        _history.value = next
        writeStations(K_HISTORY, next)
    }

    fun clearHistory() { _history.value = emptyList(); writeStations(K_HISTORY, emptyList()) }

    fun addSearch(q: String) {
        val t = q.trim()
        if (t.length < 2) return
        val next = (listOf(t) + _searches.value.filterNot { it.equals(t, ignoreCase = true) }).take(12)
        _searches.value = next
        writeStrings(K_SEARCHES, next)
    }

    fun clearSearches() { _searches.value = emptyList(); writeStrings(K_SEARCHES, emptyList()) }

    fun hide(uuid: String) {
        val next = _hidden.value + uuid
        _hidden.value = next
        writeStrings(K_HIDDEN, next.toList())
    }

    fun restoreHidden() { _hidden.value = emptySet(); writeStrings(K_HIDDEN, emptyList()) }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val n = transform(_settings.value)
        _settings.value = n
        sp.edit()
            .putString(K_THEME, n.theme.name)
            .putBoolean(K_WIFI_ONLY, n.wifiOnly)
            .putBoolean(K_WARN_MOBILE, n.warnMobile)
            .putBoolean(K_RECONNECT, n.autoReconnect)
            .putBoolean(K_FADE, n.sleepFade)
            .apply()
    }

    fun addDataUsage(mb: Double) {
        if (mb <= 0) return
        val n = _dataMb.value + mb
        _dataMb.value = n
        sp.edit().putFloat(K_DATA, n.toFloat()).apply()
    }

    fun resetDataUsage() { _dataMb.value = 0.0; sp.edit().putFloat(K_DATA, 0f).apply() }

    private fun readSettings() = AppSettings(
        theme = runCatching { ThemeMode.valueOf(sp.getString(K_THEME, null) ?: "SYSTEM") }.getOrDefault(ThemeMode.SYSTEM),
        wifiOnly = sp.getBoolean(K_WIFI_ONLY, false),
        warnMobile = sp.getBoolean(K_WARN_MOBILE, true),
        autoReconnect = sp.getBoolean(K_RECONNECT, true),
        sleepFade = sp.getBoolean(K_FADE, true),
    )

    private fun readStations(key: String): List<Station> = try {
        val arr = JSONArray(sp.getString(key, "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Station.fromJson(it) } }
    } catch (e: Exception) { emptyList() }

    private fun writeStations(key: String, list: List<Station>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString(key, arr.toString()).apply()
    }

    private fun readStrings(key: String): List<String> = try {
        val arr = JSONArray(sp.getString(key, "[]") ?: "[]")
        (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    } catch (e: Exception) { emptyList() }

    private fun writeStrings(key: String, list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        sp.edit().putString(key, arr.toString()).apply()
    }

    private companion object {
        const val K_FAV = "favorites"
        const val K_HISTORY = "history"
        const val K_SEARCHES = "recent_searches"
        const val K_HIDDEN = "hidden"
        const val K_THEME = "theme"
        const val K_WIFI_ONLY = "wifi_only"
        const val K_WARN_MOBILE = "warn_mobile"
        const val K_RECONNECT = "auto_reconnect"
        const val K_FADE = "sleep_fade"
        const val K_DATA = "data_mb"
    }
}
