@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.BuildConfig
import com.worldwave.radio.R
import com.worldwave.radio.data.ThemeMode
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.ScreenHeader
import com.worldwave.radio.util.formatMb

@Composable
fun SettingsScreen() {
    val app = app()
    val actions = LocalActions.current
    val settings by app.prefs.settings.collectAsStateWithLifecycle()
    val hidden by app.prefs.hidden.collectAsStateWithLifecycle()
    val totalMb by app.prefs.dataMb.collectAsStateWithLifecycle()
    val done = stringResource(R.string.done)
    val currentLang = remember { AppCompatDelegate.getApplicationLocales().toLanguageTags() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { ScreenHeader(stringResource(R.string.tab_settings)) }

        item { GroupTitle(stringResource(R.string.appearance)) }
        item {
            ChoiceRow(
                label = stringResource(R.string.theme),
                options = listOf(
                    ThemeMode.SYSTEM to stringResource(R.string.theme_system),
                    ThemeMode.LIGHT to stringResource(R.string.theme_light),
                    ThemeMode.DARK to stringResource(R.string.theme_dark),
                ),
                selected = settings.theme,
                onSelect = { mode -> app.prefs.updateSettings { it.copy(theme = mode) } },
            )
        }
        item {
            val selected = when {
                currentLang.startsWith("ar") -> "ar"
                currentLang.startsWith("en") -> "en"
                else -> ""
            }
            ChoiceRow(
                label = stringResource(R.string.language),
                options = listOf(
                    "" to stringResource(R.string.lang_system),
                    "en" to stringResource(R.string.lang_en),
                    "ar" to stringResource(R.string.lang_ar),
                ),
                selected = selected,
                onSelect = { tag ->
                    AppCompatDelegate.setApplicationLocales(
                        if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                        else LocaleListCompat.forLanguageTags(tag)
                    )
                },
            )
        }

        item { GroupTitle(stringResource(R.string.playback)) }
        item {
            SwitchRow(stringResource(R.string.auto_reconnect), stringResource(R.string.auto_reconnect_desc), settings.autoReconnect) { v ->
                app.prefs.updateSettings { it.copy(autoReconnect = v) }
            }
        }
        item {
            SwitchRow(stringResource(R.string.sleep_fade), null, settings.sleepFade) { v ->
                app.prefs.updateSettings { it.copy(sleepFade = v) }
            }
        }

        item { GroupTitle(stringResource(R.string.data)) }
        item {
            SwitchRow(stringResource(R.string.wifi_only), stringResource(R.string.wifi_only_desc), settings.wifiOnly) { v ->
                app.prefs.updateSettings { it.copy(wifiOnly = v) }
            }
        }
        item {
            SwitchRow(stringResource(R.string.warn_mobile), null, settings.warnMobile) { v ->
                app.prefs.updateSettings { it.copy(warnMobile = v) }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.data_total), style = MaterialTheme.typography.bodyLarge)
                    Text(
                        stringResource(R.string.data_total_value, formatMb(totalMb)),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                TextButton(onClick = { app.prefs.resetDataUsage() }) { Text(stringResource(R.string.reset)) }
            }
        }
        item { Note(stringResource(R.string.data_note)) }

        item { GroupTitle(stringResource(R.string.privacy)) }
        item { ActionRow(stringResource(R.string.clear_history)) { app.prefs.clearHistory(); actions.message(done) } }
        item { ActionRow(stringResource(R.string.clear_searches)) { app.prefs.clearSearches(); actions.message(done) } }
        if (hidden.isNotEmpty()) {
            item { ActionRow(stringResource(R.string.restore_hidden, hidden.size)) { app.prefs.restoreHidden(); actions.message(done) } }
        }
        item { ActionRow(stringResource(R.string.clear_cache)) { app.repo.clearCache(); actions.message(done) } }

        item { GroupTitle(stringResource(R.string.about)) }
        item { Note(stringResource(R.string.version, BuildConfig.VERSION_NAME)) }
        item { Note(stringResource(R.string.source_note)) }
        item { Note(stringResource(R.string.privacy_note)) }
    }
}

@Composable
private fun GroupTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 6.dp),
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
    )
}

@Composable
private fun <T> ChoiceRow(label: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, text) ->
                FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(text) })
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, description: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (description != null) {
                Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ActionRow(title: String, onClick: () -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
    )
}
