package com.worldwave.radio.data

import com.worldwave.radio.util.isPlayableUrl
import org.json.JSONObject

data class Station(
    val uuid: String,
    val name: String,
    val url: String = "",
    val urlResolved: String = "",
    val favicon: String = "",
    val country: String = "",
    val countryCode: String = "",
    val state: String = "",
    val language: String = "",
    val tags: String = "",
    val codec: String = "",
    val bitrate: Int = 0,
    val hls: Boolean = false,
    val homepage: String = "",
    val clicks: Int = 0,
    val votes: Int = 0,
) {
    val playUrl: String get() = urlResolved.ifBlank { url }
    val fallbackUrl: String? get() = url.takeIf { it.isNotBlank() && it != playUrl && isPlayableUrl(it) }
    val tagList: List<String> get() = tags.split(',').map { it.trim() }.filter { it.isNotEmpty() }

    fun toJson(): JSONObject = JSONObject().apply {
        put("stationuuid", uuid); put("name", name); put("url", url); put("url_resolved", urlResolved)
        put("favicon", favicon); put("country", country); put("countrycode", countryCode); put("state", state)
        put("language", language); put("tags", tags); put("codec", codec); put("bitrate", bitrate)
        put("hls", if (hls) 1 else 0); put("homepage", homepage); put("clickcount", clicks); put("votes", votes)
    }

    companion object {
        private fun JSONObject.str(key: String): String =
            if (!has(key) || isNull(key)) "" else optString(key, "").trim()

        fun fromJson(o: JSONObject): Station? {
            val uuid = o.str("stationuuid")
            if (uuid.isBlank()) return null
            return Station(
                uuid = uuid,
                name = o.str("name").ifBlank { "Radio" },
                url = o.str("url"),
                urlResolved = o.str("url_resolved"),
                favicon = o.str("favicon"),
                country = o.str("country"),
                countryCode = o.str("countrycode").uppercase(),
                state = o.str("state"),
                language = o.str("language"),
                tags = o.str("tags"),
                codec = o.str("codec"),
                bitrate = o.optInt("bitrate", 0),
                hls = o.optInt("hls", 0) == 1,
                homepage = o.str("homepage"),
                clicks = o.optInt("clickcount", 0),
                votes = o.optInt("votes", 0),
            )
        }
    }
}

data class Country(val code: String, val name: String, val count: Int)
data class NamedCount(val name: String, val count: Int)
data class Page(val stations: List<Station>, val rawCount: Int)

data class StationQuery(
    val name: String? = null,
    val countryCode: String? = null,
    val language: String? = null,
    val tag: String? = null,
    val order: String = "clickcount",
)

/** Drops unusable URLs, hidden stations and duplicates (same id, or same name + stream URL). */
fun List<Station>.cleaned(hidden: Set<String> = emptySet()): List<Station> {
    val seen = HashSet<String>()
    val out = ArrayList<Station>(size)
    for (s in this) {
        if (s.uuid in hidden || !isPlayableUrl(s.playUrl)) continue
        val key = s.name.trim().lowercase() + "|" + s.playUrl.trim().lowercase().trimEnd('/')
        if (s.uuid in seen || key in seen) continue
        seen.add(s.uuid); seen.add(key); out.add(s)
    }
    return out
}
