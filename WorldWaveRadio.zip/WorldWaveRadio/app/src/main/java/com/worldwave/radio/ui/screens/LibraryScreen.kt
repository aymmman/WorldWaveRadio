@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.R
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.MessageBox
import com.worldwave.radio.ui.components.ScreenHeader
import com.worldwave.radio.ui.components.StationRow
import com.worldwave.radio.ui.currentLocale

@Composable
fun LibraryScreen(onExplore: () -> Unit) {
    val app = app()
    val actions = LocalActions.current
    val locale = currentLocale()
    val favorites by app.prefs.favorites.collectAsStateWithLifecycle()
    val history by app.prefs.history.collectAsStateWithLifecycle()
    val ui by app.player.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val list = if (tab == 0) favorites else history

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.tab_library)) {
            if (tab == 1 && history.isNotEmpty()) {
                TextButton(onClick = { app.prefs.clearHistory() }) { Text(stringResource(R.string.clear)) }
            }
        }
        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(stringResource(R.string.favorites)) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(stringResource(R.string.recent)) })
        }
        if (list.isEmpty()) {
            if (tab == 0) {
                MessageBox(Icons.Filled.FavoriteBorder, stringResource(R.string.empty_favorites), stringResource(R.string.explore_stations), onExplore)
            } else {
                MessageBox(Icons.Filled.History, stringResource(R.string.empty_history), stringResource(R.string.explore_stations), onExplore)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
                items(list, key = { it.uuid }) { s ->
                    StationRow(
                        station = s,
                        locale = locale,
                        isFavorite = favorites.any { it.uuid == s.uuid },
                        isCurrent = ui.station?.uuid == s.uuid,
                        isPlaying = ui.isPlaying,
                        onClick = { actions.play(s, list) },
                        onToggleFavorite = { app.prefs.toggleFavorite(s) },
                    )
                }
            }
        }
    }
}
