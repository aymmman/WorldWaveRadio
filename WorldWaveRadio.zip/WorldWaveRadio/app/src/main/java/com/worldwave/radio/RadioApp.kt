package com.worldwave.radio

import android.app.Application
import com.worldwave.radio.data.Prefs
import com.worldwave.radio.data.RadioRepository
import com.worldwave.radio.playback.PlayerConnection

class RadioApp : Application() {
    lateinit var prefs: Prefs
        private set
    lateinit var repo: RadioRepository
        private set
    lateinit var player: PlayerConnection
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        repo = RadioRepository(this)
        player = PlayerConnection(this, prefs, repo)
    }
}
