package com.worldwave.radio

import android.app.Application
import com.worldwave.radio.data.Prefs
import com.worldwave.radio.data.RadioRepository
import com.worldwave.radio.playback.PlayerConnection
import com.worldwave.radio.playback.RadioService
import com.worldwave.radio.wear.WearBridge

class RadioApp : Application(), RadioHost {
    override lateinit var prefs: Prefs
        private set
    lateinit var repo: RadioRepository
        private set
    lateinit var player: PlayerConnection
        private set
    lateinit var wearBridge: WearBridge
        private set

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        repo = RadioRepository(this)
        player = PlayerConnection(this, prefs, repo, RadioService::class.java)
        wearBridge = WearBridge(this, prefs, player).also { it.start() }
    }
}
