@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.worldwave.radio.R
import com.worldwave.radio.ui.Load
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.Genres
import com.worldwave.radio.ui.components.GenreTile
import com.worldwave.radio.ui.components.LoadContent
import com.worldwave.radio.ui.components.LoadingBox
import com.worldwave.radio.ui.components.MessageBox
import com.worldwave.radio.ui.components.ScreenHeader
import com.worldwave.radio.ui.components.SectionHeader
import com.worldwave.radio.ui.currentLocale
import com.worldwave.radio.ui.loadable
import com.worldwave.radio.util.countryName
import com.worldwave.radio.util.flagEmoji
import com.worldwave.radio.util.prettyLanguage

@Composable
fun ExploreScreen() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf(R.string.countries, R.string.languages, R.string.genres)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.tab_explore))
        TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
            titles.forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(stringResource(t)) })
            }
        }
        when (tab) {
            0 -> CountriesTab()
            1 -> LanguagesTab()
            else -> GenresTab()
        }
    }
}

@Composable
private fun CountRow(leading: @Composable () -> Unit, title: String, count: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh),
            contentAlignment = Alignment.Center,
        ) { leading() }
        Spacer(Modifier.width(14.dp))
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        Text(
            stringResource(R.string.stations_count, count),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun IconLead(icon: ImageVector) {
    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
}

@Composable
private fun CountriesTab() {
    val app = app()
    val actions = LocalActions.current
    val locale = currentLocale()
    var filter by rememberSaveable { mutableStateOf("") }
    val handle = loadable("countries") { app.repo.countries() }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = filter,
            onValueChange = { filter = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            placeholder = { Text(stringResource(R.string.filter_countries)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
        )
        LoadContent(handle) { list ->
            val named = remember(list, locale) { list.map { it to countryName(it.code, it.name, locale) } }
            val q = filter.trim()
            val shown = if (q.isEmpty()) named else named.filter { (c, n) ->
                n.contains(q, ignoreCase = true) || c.name.contains(q, ignoreCase = true)
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown, key = { it.first.code }) { (c, n) ->
                    CountRow({ Text(flagEmoji(c.code), fontSize = 22.sp) }, n, c.count) {
                        actions.openList("country", c.code, n)
                    }
                }
            }
        }
    }
}

@Composable
private fun LanguagesTab() {
    val app = app()
    val actions = LocalActions.current
    val handle = loadable("languages") { app.repo.languages() }
    LoadContent(handle) { list ->
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(list, key = { it.name }) { lang ->
                val title = prettyLanguage(lang.name)
                CountRow({ IconLead(Icons.Filled.Translate) }, title, lang.count) {
                    actions.openList("language", lang.name, title)
                }
            }
        }
    }
}

@Composable
private fun GenresTab() {
    val app = app()
    val actions = LocalActions.current
    val handle = loadable("tags") { app.repo.tags() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)) {
        Genres.chunked(2).forEach { row ->
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    row.forEach { g ->
                        GenreTile(g, Modifier.weight(1f)) { genre, label -> actions.openList("tag", genre.tag, label) }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        item { SectionHeader(stringResource(R.string.all_genres)) }
        when (val s = handle.state) {
            is Load.Loading -> item { LoadingBox() }
            is Load.Fail -> item {
                MessageBox(Icons.Filled.CloudOff, stringResource(R.string.error_load), stringResource(R.string.retry), handle.retry)
            }
            is Load.Ok -> items(s.value, key = { "tag-" + it.name }) { t ->
                val title = prettyLanguage(t.name)
                CountRow({ IconLead(Icons.Filled.LocalOffer) }, title, t.count) {
                    actions.openList("tag", t.name, title)
                }
            }
        }
    }
}
