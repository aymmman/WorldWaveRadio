package com.worldwave.radio.util

import java.util.Locale
import kotlin.math.roundToInt

/** Estimated megabytes for a stream at [bitrateKbps] over [seconds]. Returns 0 when bitrate is unknown. */
fun estimateMb(bitrateKbps: Int, seconds: Long): Double =
    if (bitrateKbps <= 0 || seconds <= 0) 0.0
    else bitrateKbps * 1000.0 / 8.0 * seconds / (1024.0 * 1024.0)

fun mbPerHour(bitrateKbps: Int): Int = estimateMb(bitrateKbps, 3600).roundToInt()

fun formatDuration(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

fun formatMb(mb: Double): String =
    if (mb < 10) String.format(Locale.US, "%.1f", mb) else mb.roundToInt().toString()

fun flagEmoji(code: String): String {
    val c = code.trim().uppercase(Locale.US)
    if (c.length != 2 || !c.all { it in 'A'..'Z' }) return "🌐"
    val first = c[0].code - 'A'.code + 0x1F1E6
    val second = c[1].code - 'A'.code + 0x1F1E6
    return String(Character.toChars(first)) + String(Character.toChars(second))
}

fun initials(name: String): String {
    val words = name.split(Regex("\\s+")).filter { it.isNotBlank() && it.first().isLetterOrDigit() }
    return words.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "♪" }
}

fun prettyLanguage(raw: String): String =
    raw.split(',').firstOrNull()?.trim()?.replaceFirstChar { it.titlecase(Locale.getDefault()) } ?: ""

fun isPlayableUrl(u: String): Boolean =
    u.startsWith("http://", ignoreCase = true) || u.startsWith("https://", ignoreCase = true)

fun countryName(code: String, fallback: String, locale: Locale): String {
    if (code.length != 2) return fallback
    val n = Locale("", code).getDisplayCountry(locale)
    return if (n.isBlank() || n.equals(code, ignoreCase = true)) fallback.ifBlank { code } else n
}
