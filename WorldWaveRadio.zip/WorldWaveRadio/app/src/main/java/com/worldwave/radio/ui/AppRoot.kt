@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui

import android.net.Uri
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.worldwave.radio.R
import com.worldwave.radio.RadioApp
import com.worldwave.radio.data.Station
import com.worldwave.radio.ui.components.MiniPlayer
import com.worldwave.radio.ui.screens.ExploreScreen
import com.worldwave.radio.ui.screens.HomeScreen
import com.worldwave.radio.ui.screens.LibraryScreen
import com.worldwave.radio.ui.screens.PlayerScreen
import com.worldwave.radio.ui.screens.SearchScreen
import com.worldwave.radio.ui.screens.SettingsScreen
import com.worldwave.radio.ui.screens.StationListScreen
import com.worldwave.radio.util.NetType
import com.worldwave.radio.util.currentNetwork
import com.worldwave.radio.util.mbPerHour
import kotlinx.coroutines.launch

/** App-wide actions so screens stay simple. */
class Actions(
    val play: (Station, List<Station>) -> Unit,
    val openPlayer: () -> Unit,
    val openList: (kind: String, value: String, title: String) -> Unit,
    val message: (String) -> Unit,
)

val LocalActions = staticCompositionLocalOf<Actions> { error("Actions not provided") }

private data class Tab(val route: String, @StringRes val label: Int, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", R.string.tab_home, Icons.Filled.Home),
    Tab("explore", R.string.tab_explore, Icons.Filled.Explore),
    Tab("search", R.string.tab_search, Icons.Filled.Search),
    Tab("library", R.string.tab_library, Icons.Filled.LibraryMusic),
    Tab("settings", R.string.tab_settings, Icons.Filled.Settings),
)

private fun NavController.navigateTab(route: String) = navigate(route) {
    popUpTo(graph.findStartDestination().id) { saveState = true }
    launchSingleTop = true
    restoreState = true
}

@Composable
fun AppRoot(app: RadioApp) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val ui by app.player.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var pendingPlay by remember { mutableStateOf<Pair<Station, List<Station>>?>(null) }
    var mobileAccepted by rememberSaveable { mutableStateOf(false) }
    val msgWifiOnly = stringResource(R.string.wifi_only_blocked)
    val msgOffline = stringResource(R.string.no_connection)

    val showMessage: (String) -> Unit = { text -> scope.launch { snackbar.showSnackbar(text) } }

    val requestPlay: (Station, List<Station>) -> Unit = { station, list ->
        val settings = app.prefs.settings.value
        when (currentNetwork(context)) {
            NetType.NONE -> showMessage(msgOffline)
            NetType.METERED -> when {
                settings.wifiOnly -> showMessage(msgWifiOnly)
                settings.warnMobile && !mobileAccepted -> pendingPlay = station to list
                else -> app.player.play(station, list)
            }
            NetType.UNMETERED -> app.player.play(station, list)
        }
        Unit
    }

    val actions = remember(nav) {
        Actions(
            play = { s, l -> requestPlay(s, l) },
            openPlayer = { nav.navigate("player") { launchSingleTop = true } },
            openList = { kind, value, title ->
                nav.navigate("list/$kind/${Uri.encode(value)}/${Uri.encode(title)}")
            },
            message = showMessage,
        )
    }

    CompositionLocalProvider(LocalActions provides actions) {
        val isTop = tabs.any { it.route == route }
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                if (route != "player") {
                    Column(if (isTop) Modifier else Modifier.navigationBarsPadding()) {
                        if (ui.station != null) {
                            MiniPlayer(ui, onOpen = actions.openPlayer, onToggle = { app.player.toggle() })
                        }
                        if (isTop) {
                            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                                tabs.forEach { tab ->
                                    NavigationBarItem(
                                        selected = route == tab.route,
                                        onClick = { nav.navigateTab(tab.route) },
                                        icon = { Icon(tab.icon, contentDescription = null) },
                                        label = { Text(stringResource(tab.label)) },
                                        colors = NavigationBarItemDefaults.colors(
                                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                        ),
                                    )
                                }
                            }
                        }
                    }
                }
            },
        ) { padding ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(padding)) {
                composable("home") {
                    HomeScreen(onSearch = { nav.navigateTab("search") }, onExplore = { nav.navigateTab("explore") })
                }
                composable("explore") { ExploreScreen() }
                composable("search") { SearchScreen() }
                composable("library") { LibraryScreen(onExplore = { nav.navigateTab("explore") }) }
                composable("settings") { SettingsScreen() }
                composable(
                    "list/{kind}/{value}/{title}",
                    arguments = listOf(
                        navArgument("kind") { type = NavType.StringType },
                        navArgument("value") { type = NavType.StringType },
                        navArgument("title") { type = NavType.StringType },
                    ),
                ) { entry ->
                    val args = entry.arguments
                    StationListScreen(
                        kind = args?.getString("kind") ?: "tag",
                        value = args?.getString("value") ?: "",
                        title = args?.getString("title") ?: "",
                        onBack = { nav.popBackStack() },
                    )
                }
                composable("player") { PlayerScreen(onBack = { nav.popBackStack() }) }
            }
        }

        pendingPlay?.let { (station, list) ->
            AlertDialog(
                onDismissRequest = { pendingPlay = null },
                title = { Text(stringResource(R.string.mobile_data_title)) },
                text = {
                    Text(
                        if (station.bitrate > 0) stringResource(R.string.mobile_data_body, station.bitrate, mbPerHour(station.bitrate))
                        else stringResource(R.string.data_unknown)
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        mobileAccepted = true
                        pendingPlay = null
                        app.player.play(station, list)
                    }) { Text(stringResource(R.string.play_anyway)) }
                },
                dismissButton = {
                    TextButton(onClick = { pendingPlay = null }) { Text(stringResource(R.string.cancel)) }
                },
            )
        }
    }
}
