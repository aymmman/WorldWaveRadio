@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.R
import com.worldwave.radio.data.StationQuery
import com.worldwave.radio.ui.valueOrNull
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.Genres
import com.worldwave.radio.ui.components.LoadContent
import com.worldwave.radio.ui.components.MessageBox
import com.worldwave.radio.ui.components.SectionHeader
import com.worldwave.radio.ui.components.StationRow
import com.worldwave.radio.ui.currentLocale
import com.worldwave.radio.ui.loadable
import com.worldwave.radio.util.countryName
import com.worldwave.radio.util.flagEmoji
import kotlinx.coroutines.delay

@Composable
fun SearchScreen() {
    val app = app()
    val actions = LocalActions.current
    val locale = currentLocale()
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = remember { FocusRequester() }
    val favorites by app.prefs.favorites.collectAsStateWithLifecycle()
    val hidden by app.prefs.hidden.collectAsStateWithLifecycle()
    val recent by app.prefs.searches.collectAsStateWithLifecycle()
    val ui by app.player.state.collectAsStateWithLifecycle()

    var text by rememberSaveable { mutableStateOf("") }
    var query by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(text) {
        delay(350)
        query = text.trim()
    }
    LaunchedEffect(Unit) { if (text.isEmpty()) runCatching { focus.requestFocus() } }

    val countries = loadable("countries") { app.repo.countries() }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)
                .focusRequester(focus),
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (text.isNotEmpty()) {
                    IconButton(onClick = { text = ""; query = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.clear))
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                app.prefs.addSearch(text)
                query = text.trim()
                keyboard?.hide()
            }),
        )

        if (query.length < 2) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                if (recent.isNotEmpty()) {
                    item {
                        SectionHeader(stringResource(R.string.recent_searches), stringResource(R.string.clear)) {
                            app.prefs.clearSearches()
                        }
                    }
                    items(recent, key = { "q-$it" }) { q ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { text = q; query = q }
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.History, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.width(14.dp))
                            Text(q, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
                item { SectionHeader(stringResource(R.string.try_genre)) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        items(Genres, key = { it.tag }) { g ->
                            val label = stringResource(g.label)
                            AssistChip(
                                onClick = { actions.openList("tag", g.tag, label) },
                                label = { Text(label) },
                                leadingIcon = { Icon(g.icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
                            )
                        }
                    }
                }
            }
        } else {
            val results = loadable("search", query) {
                app.repo.search(StationQuery(name = query), 0, 60).stations
            }
            val matchingCountries = countries.state.valueOrNull().orEmpty()
                .map { it to countryName(it.code, it.name, locale) }
                .filter { (c, n) -> n.contains(query, ignoreCase = true) || c.name.contains(query, ignoreCase = true) }
                .take(10)

            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                if (matchingCountries.isNotEmpty()) {
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            items(matchingCountries, key = { it.first.code }) { (c, n) ->
                                AssistChip(
                                    onClick = { actions.openList("country", c.code, n) },
                                    label = { Text(flagEmoji(c.code) + "  " + n) },
                                )
                            }
                        }
                    }
                }
                item {
                    LoadContent(results) { list ->
                        if (list.none { it.uuid !in hidden }) {
                            MessageBox(Icons.Filled.Radio, stringResource(R.string.empty_results))
                        }
                    }
                }
                val list = results.state.valueOrNull().orEmpty().filter { it.uuid !in hidden }
                items(list, key = { it.uuid }) { s ->
                    StationRow(
                        station = s,
                        locale = locale,
                        isFavorite = favorites.any { it.uuid == s.uuid },
                        isCurrent = ui.station?.uuid == s.uuid,
                        isPlaying = ui.isPlaying,
                        onClick = {
                            app.prefs.addSearch(query)
                            keyboard?.hide()
                            actions.play(s, list)
                        },
                        onToggleFavorite = { app.prefs.toggleFavorite(s) },
                    )
                }
            }
        }
    }
}
