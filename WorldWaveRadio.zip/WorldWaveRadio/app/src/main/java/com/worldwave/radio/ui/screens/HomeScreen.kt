@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.R
import com.worldwave.radio.data.Station
import com.worldwave.radio.data.StationQuery
import com.worldwave.radio.playback.PlayerUi
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.CountryTile
import com.worldwave.radio.ui.components.GenreRail
import com.worldwave.radio.ui.components.LoadContent
import com.worldwave.radio.ui.components.SectionHeader
import com.worldwave.radio.ui.components.StationArt
import com.worldwave.radio.ui.components.StationRail
import com.worldwave.radio.ui.components.TuningDial
import com.worldwave.radio.ui.components.stationSubtitle
import com.worldwave.radio.ui.currentLocale
import com.worldwave.radio.ui.loadable
import com.worldwave.radio.util.countryName
import java.util.Locale

@Composable
fun HomeScreen(onSearch: () -> Unit, onExplore: () -> Unit) {
    val app = app()
    val actions = LocalActions.current
    val locale = currentLocale()
    val history by app.prefs.history.collectAsStateWithLifecycle()
    val hidden by app.prefs.hidden.collectAsStateWithLifecycle()
    val ui by app.player.state.collectAsStateWithLifecycle()

    val top = loadable("home-top") { app.repo.top(40) }
    val arabic = loadable("home-arabic") { app.repo.search(StationQuery(language = "arabic"), 0, 30).stations }
    val countries = loadable("home-countries") { app.repo.countries() }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { HomeHeader(ui, onSearch) }

        val last = history.firstOrNull()
        if (last != null && ui.station == null) {
            item { ContinueCard(last, locale) { actions.play(last, history) } }
        }

        if (history.isNotEmpty()) {
            item { SectionHeader(stringResource(R.string.recently_played)) }
            item { StationRail(history.take(15), ui, locale) { s -> actions.play(s, history) } }
        }

        item { SectionHeader(stringResource(R.string.popular_now)) }
        item {
            LoadContent(top) { list ->
                val shown = list.filter { it.uuid !in hidden }
                StationRail(shown, ui, locale) { s -> actions.play(s, shown) }
            }
        }

        item { SectionHeader(stringResource(R.string.browse_genres)) }
        item { GenreRail { genre, label -> actions.openList("tag", genre.tag, label) } }

        item {
            val title = stringResource(R.string.arabic_radio)
            SectionHeader(title, stringResource(R.string.see_all)) { actions.openList("language", "arabic", title) }
        }
        item {
            LoadContent(arabic) { list ->
                val shown = list.filter { it.uuid !in hidden }
                StationRail(shown, ui, locale) { s -> actions.play(s, shown) }
            }
        }

        item { SectionHeader(stringResource(R.string.countries), stringResource(R.string.see_all), onExplore) }
        item {
            LoadContent(countries, loadingHeight = 100.dp) { list ->
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    items(list.take(24), key = { it.code }) { c ->
                        CountryTile(c, locale) {
                            actions.openList("country", c.code, countryName(c.code, c.name, locale))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(ui: PlayerUi, onSearch: () -> Unit) {
    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp)) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.home_tagline),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        TuningDial(
            seed = ui.station?.uuid ?: "worldwave",
            active = ui.isPlaying,
            modifier = Modifier.padding(vertical = 14.dp),
        )
        Surface(
            onClick = onSearch,
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(12.dp))
                Text(
                    stringResource(R.string.search_hint),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ContinueCard(station: Station, locale: Locale, onPlay: () -> Unit) {
    Surface(
        onClick = onPlay,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 20.dp),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            StationArt(station.name, station.favicon, 60.dp, corner = 16.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.continue_listening),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                )
                Text(
                    station.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    stationSubtitle(station, locale),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            FilledIconButton(onClick = onPlay) {
                Icon(Icons.Filled.PlayArrow, contentDescription = stringResource(R.string.play))
            }
        }
    }
}
