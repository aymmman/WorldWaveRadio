package com.worldwave.radio.playback

import android.content.Intent
import com.worldwave.radio.MainActivity

class RadioService : BaseRadioService() {
    override fun launchIntent(): Intent =
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
}
