package com.worldwave.radio.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.worldwave.radio.data.ThemeMode

/** Night-sky navy with the warm amber of an old radio dial. */
private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB23E),
    onPrimary = Color(0xFF2A1700),
    primaryContainer = Color(0xFF4A3000),
    onPrimaryContainer = Color(0xFFFFDDB0),
    secondary = Color(0xFF6FD3FF),
    onSecondary = Color(0xFF00344A),
    secondaryContainer = Color(0xFF1B3B66),
    onSecondaryContainer = Color(0xFFCDE9FF),
    background = Color(0xFF0D1530),
    onBackground = Color(0xFFEEF1FF),
    surface = Color(0xFF0D1530),
    onSurface = Color(0xFFEEF1FF),
    surfaceVariant = Color(0xFF212D5E),
    onSurfaceVariant = Color(0xFFA3ACD0),
    surfaceContainerLowest = Color(0xFF0A1027),
    surfaceContainerLow = Color(0xFF121B3D),
    surfaceContainer = Color(0xFF16204A),
    surfaceContainerHigh = Color(0xFF1D2855),
    surfaceContainerHighest = Color(0xFF263366),
    outline = Color(0xFF3A4675),
    outlineVariant = Color(0xFF2A3560),
    error = Color(0xFFFF8A80),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF9A5B00),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE2BC),
    onPrimaryContainer = Color(0xFF2A1700),
    secondary = Color(0xFF0A6E9E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3ECFF),
    onSecondaryContainer = Color(0xFF00344A),
    background = Color(0xFFF5F6FB),
    onBackground = Color(0xFF141936),
    surface = Color(0xFFF5F6FB),
    onSurface = Color(0xFF141936),
    surfaceVariant = Color(0xFFE6E9F5),
    onSurfaceVariant = Color(0xFF545B80),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF1F3FA),
    surfaceContainer = Color(0xFFECEFF8),
    surfaceContainerHigh = Color(0xFFE4E8F4),
    surfaceContainerHighest = Color(0xFFDDE2F0),
    outline = Color(0xFFB7BDD6),
    outlineVariant = Color(0xFFD6DAEA),
)

private val BaseType = Typography()
private val AppTypography = BaseType.copy(
    headlineLarge = BaseType.headlineLarge.copy(fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp),
    headlineMedium = BaseType.headlineMedium.copy(fontWeight = FontWeight.Bold),
    headlineSmall = BaseType.headlineSmall.copy(fontWeight = FontWeight.Bold),
    titleLarge = BaseType.titleLarge.copy(fontWeight = FontWeight.Bold),
    titleMedium = BaseType.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = BaseType.titleSmall.copy(fontWeight = FontWeight.SemiBold),
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
)

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun WorldWaveTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            view.context.findActivity()?.window?.let { window ->
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content,
    )
}
