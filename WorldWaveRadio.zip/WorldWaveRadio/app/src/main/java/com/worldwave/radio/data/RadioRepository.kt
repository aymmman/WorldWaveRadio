package com.worldwave.radio.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

class RadioRepository(context: Context) {
    private val api = RadioApi()
    private val dir = File(context.cacheDir, "directory").apply { mkdirs() }
    private val memory = ConcurrentHashMap<String, Pair<Long, String>>()

    /** Memory cache, then disk cache, then network. Falls back to stale disk data when offline. */
    private suspend fun fetch(path: String, ttlMs: Long): String = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        memory[path]?.let { (time, body) -> if (now - time < ttlMs) return@withContext body }
        val file = File(dir, fileName(path))
        if (file.exists() && now - file.lastModified() < ttlMs) {
            val body = file.readText()
            memory[path] = file.lastModified() to body
            return@withContext body
        }
        try {
            val body = api.get(path)
            runCatching { file.writeText(body) }
            memory[path] = now to body
            body
        } catch (e: Exception) {
            if (file.exists()) file.readText() else throw e
        }
    }

    private fun fileName(path: String): String {
        val digest = MessageDigest.getInstance("MD5").digest(path.toByteArray())
        return digest.joinToString("") { "%02x".format(it) } + ".json"
    }

    private suspend fun parseStations(body: String): List<Station> = withContext(Dispatchers.Default) {
        val arr = JSONArray(body)
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Station.fromJson(it) } }
    }

    suspend fun top(limit: Int = 40): List<Station> =
        parseStations(fetch("/json/stations/topclick?hidebroken=true&limit=$limit", HOUR)).cleaned()

    suspend fun search(q: StationQuery, offset: Int, limit: Int): Page {
        val raw = parseStations(fetch(q.toPath(offset, limit), 30 * MINUTE))
        return Page(raw.cleaned(), raw.size)
    }

    suspend fun similar(s: Station): List<Station> {
        val tag = s.tagList.firstOrNull()
        val query = if (tag != null) StationQuery(tag = tag)
        else if (s.countryCode.isNotBlank()) StationQuery(countryCode = s.countryCode)
        else return emptyList()
        return search(query, 0, 25).stations.filter { it.uuid != s.uuid }
    }

    suspend fun countries(): List<Country> {
        val body = fetch("/json/countries?order=stationcount&reverse=true&hidebroken=true", DAY)
        return withContext(Dispatchers.Default) {
            val arr = JSONArray(body)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val code = o.optString("iso_3166_1", "").trim().uppercase()
                val count = o.optInt("stationcount", 0)
                if (code.length != 2 || count <= 0) null
                else Country(code, o.optString("name", code).trim(), count)
            }.groupBy { it.code }.map { (_, v) -> v.maxBy { it.count } }.sortedByDescending { it.count }
        }
    }

    suspend fun languages(): List<NamedCount> =
        namedCounts(fetch("/json/languages?order=stationcount&reverse=true&hidebroken=true&limit=120", DAY), 5)

    suspend fun tags(): List<NamedCount> =
        namedCounts(fetch("/json/tags?order=stationcount&reverse=true&hidebroken=true&limit=120", DAY), 20)

    private suspend fun namedCounts(body: String, min: Int): List<NamedCount> = withContext(Dispatchers.Default) {
        val arr = JSONArray(body)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = o.optString("name", "").trim()
            val count = o.optInt("stationcount", 0)
            if (name.isBlank() || count < min) null else NamedCount(name, count)
        }.distinctBy { it.name.lowercase() }
    }

    /** Tells Radio Browser a station was played (their click counter). Failures are ignored. */
    suspend fun registerClick(uuid: String) {
        withContext(Dispatchers.IO) { runCatching { api.get("/json/url/$uuid") } }
    }

    fun clearCache() {
        memory.clear()
        dir.listFiles()?.forEach { it.delete() }
    }

    private fun StationQuery.toPath(offset: Int, limit: Int): String {
        val p = mutableListOf<Pair<String, String>>()
        name?.let { p += "name" to it }
        countryCode?.let { p += "countrycode" to it }
        language?.let { p += "language" to it }
        tag?.let { p += "tag" to it }
        p += "order" to order
        p += "reverse" to (if (order == "name") "false" else "true")
        p += "hidebroken" to "true"
        p += "offset" to offset.toString()
        p += "limit" to limit.toString()
        return "/json/stations/search?" + p.joinToString("&") { (k, v) -> k + "=" + URLEncoder.encode(v, "UTF-8") }
    }

    companion object {
        private const val MINUTE = 60_000L
        private const val HOUR = 60 * MINUTE
        private const val DAY = 24 * HOUR
    }
}
