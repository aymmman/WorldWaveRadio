@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.worldwave.radio.R
import com.worldwave.radio.data.Station
import com.worldwave.radio.data.StationQuery
import com.worldwave.radio.ui.LocalActions
import com.worldwave.radio.ui.app
import com.worldwave.radio.ui.components.LoadingBox
import com.worldwave.radio.ui.components.MessageBox
import com.worldwave.radio.ui.components.ScreenHeader
import com.worldwave.radio.ui.components.StationRow
import com.worldwave.radio.ui.currentLocale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

private const val PAGE = 40

private data class SortOption(val order: String, val label: Int)

private val sortOptions = listOf(
    SortOption("clickcount", R.string.sort_popular),
    SortOption("votes", R.string.sort_votes),
    SortOption("bitrate", R.string.sort_quality),
    SortOption("name", R.string.sort_name),
)

@Composable
fun StationListScreen(kind: String, value: String, title: String, onBack: () -> Unit) {
    val app = app()
    val actions = LocalActions.current
    val locale = currentLocale()
    val favorites by app.prefs.favorites.collectAsStateWithLifecycle()
    val hidden by app.prefs.hidden.collectAsStateWithLifecycle()
    val ui by app.player.state.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var sort by rememberSaveable { mutableStateOf("clickcount") }
    val baseQuery = remember(kind, value) {
        when (kind) {
            "country" -> StationQuery(countryCode = value)
            "language" -> StationQuery(language = value)
            else -> StationQuery(tag = value)
        }
    }
    val items = remember(kind, value, sort) { mutableStateListOf<Station>() }
    var offset by remember(kind, value, sort) { mutableIntStateOf(0) }
    var loading by remember(kind, value, sort) { mutableStateOf(false) }
    var end by remember(kind, value, sort) { mutableStateOf(false) }
    var failed by remember(kind, value, sort) { mutableStateOf(false) }

    val loadMore: () -> Unit = {
        if (!loading && !end) {
            loading = true
            failed = false
            scope.launch {
                try {
                    val page = app.repo.search(baseQuery.copy(order = sort), offset, PAGE)
                    val known = items.mapTo(HashSet()) { it.uuid }
                    items.addAll(page.stations.filter { it.uuid !in known })
                    offset += page.rawCount
                    if (page.rawCount < PAGE) end = true
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failed = true
                } finally {
                    loading = false
                }
            }
        }
    }

    val visible = items.filter { it.uuid !in hidden }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { ScreenHeader(title, onBack) }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 8.dp),
            ) {
                items(sortOptions, key = { it.order }) { opt ->
                    FilterChip(
                        selected = sort == opt.order,
                        onClick = { sort = opt.order },
                        label = { Text(stringResource(opt.label)) },
                    )
                }
            }
        }
        items(visible, key = { it.uuid }) { s ->
            StationRow(
                station = s,
                locale = locale,
                isFavorite = favorites.any { it.uuid == s.uuid },
                isCurrent = ui.station?.uuid == s.uuid,
                isPlaying = ui.isPlaying,
                onClick = { actions.play(s, visible) },
                onToggleFavorite = { app.prefs.toggleFavorite(s) },
            )
        }
        item(key = "footer-$sort") {
            when {
                failed -> MessageBox(
                    Icons.Filled.CloudOff,
                    stringResource(R.string.error_load),
                    stringResource(R.string.retry),
                    loadMore,
                )
                end && visible.isEmpty() -> MessageBox(Icons.Filled.Radio, stringResource(R.string.empty_results))
                !end -> {
                    LoadingBox(96.dp)
                    LaunchedEffect(sort, offset) { loadMore() }
                }
            }
        }
    }
}
