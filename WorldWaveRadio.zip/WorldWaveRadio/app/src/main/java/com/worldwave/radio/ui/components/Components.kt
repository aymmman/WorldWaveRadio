@file:OptIn(ExperimentalMaterial3Api::class)

package com.worldwave.radio.ui.components

import androidx.annotation.StringRes
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.worldwave.radio.R
import com.worldwave.radio.data.Country
import com.worldwave.radio.data.Station
import com.worldwave.radio.playback.PlayError
import com.worldwave.radio.playback.PlayerUi
import com.worldwave.radio.ui.Load
import com.worldwave.radio.ui.LoadHandle
import com.worldwave.radio.util.countryName
import com.worldwave.radio.util.flagEmoji
import com.worldwave.radio.util.initials
import com.worldwave.radio.util.isPlayableUrl
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

// ---------- Station artwork ----------

private val artPalette = listOf(
    Color(0xFF3B4CCA), Color(0xFF8E3BCA), Color(0xFFB8336A), Color(0xFF1E8C7E),
    Color(0xFFB8641E), Color(0xFF2F6FB0), Color(0xFF6B4E9B), Color(0xFF9C3D3D),
)

@Composable
fun StationArt(name: String, favicon: String?, size: Dp, modifier: Modifier = Modifier, corner: Dp = 14.dp) {
    val base = remember(name) { artPalette[(name.hashCode() and 0x7fffffff) % artPalette.size] }
    var loaded by remember(favicon) { mutableStateOf(false) }
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(corner))
            .background(if (loaded) Color.White else base),
        contentAlignment = Alignment.Center,
    ) {
        if (!loaded) {
            Text(
                initials(name),
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = (size.value * 0.34f).sp,
                maxLines = 1,
            )
        }
        if (!favicon.isNullOrBlank() && isPlayableUrl(favicon)) {
            AsyncImage(
                model = favicon,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize().padding(size * 0.08f),
                onSuccess = { loaded = true },
                onError = { loaded = false },
            )
        }
    }
}

fun stationSubtitle(s: Station, locale: Locale): String {
    val parts = mutableListOf<String>()
    val country = countryName(s.countryCode, s.country, locale)
    val place = listOfNotNull(
        flagEmoji(s.countryCode).takeIf { s.countryCode.length == 2 },
        country.ifBlank { null },
    ).joinToString(" ")
    if (place.isNotBlank()) parts += place
    val quality = listOfNotNull(
        s.codec.ifBlank { null },
        s.bitrate.takeIf { it > 0 }?.let { "$it kbps" },
    ).joinToString(" ")
    if (quality.isNotBlank()) parts += quality
    return parts.joinToString(", ")
}

// ---------- Rows and cards ----------

@Composable
fun StationRow(
    station: Station,
    locale: Locale,
    isFavorite: Boolean,
    isCurrent: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StationArt(station.name, station.favicon, 52.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                station.name,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                stationSubtitle(station, locale),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (isCurrent) {
            EqualizerBars(active = isPlaying, modifier = Modifier.size(width = 18.dp, height = 16.dp))
            Spacer(Modifier.width(4.dp))
        }
        IconButton(onClick = onToggleFavorite) {
            Icon(
                if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = stringResource(if (isFavorite) R.string.remove_favorite else R.string.add_favorite),
                tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun StationCard(station: Station, locale: Locale, isCurrent: Boolean, playing: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(132.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
    ) {
        Box {
            StationArt(station.name, station.favicon, 124.dp, corner = 22.dp)
            if (isCurrent) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    EqualizerBars(
                        active = playing,
                        modifier = Modifier.size(width = 14.dp, height = 12.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            station.name,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            listOfNotNull(
                flagEmoji(station.countryCode).takeIf { station.countryCode.length == 2 },
                countryName(station.countryCode, station.country, locale).ifBlank { null },
            ).joinToString(" "),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun StationRail(stations: List<Station>, ui: PlayerUi, locale: Locale, onPlay: (Station) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(stations, key = { it.uuid }) { s ->
            StationCard(s, locale, ui.station?.uuid == s.uuid, ui.isPlaying) { onPlay(s) }
        }
    }
}

@Composable
fun CountryTile(country: Country, locale: Locale, onClick: () -> Unit) {
    Column(
        Modifier
            .width(84.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
            contentAlignment = Alignment.Center,
        ) {
            Text(flagEmoji(country.code), fontSize = 30.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(
            countryName(country.code, country.name, locale),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
        )
    }
}

// ---------- Genres ----------

data class Genre(val tag: String, @StringRes val label: Int, val icon: ImageVector)

val Genres = listOf(
    Genre("news", R.string.g_news, Icons.Filled.Article),
    Genre("pop", R.string.g_pop, Icons.Filled.MusicNote),
    Genre("rock", R.string.g_rock, Icons.Filled.Album),
    Genre("jazz", R.string.g_jazz, Icons.Filled.Headphones),
    Genre("classical", R.string.g_classical, Icons.Filled.LibraryMusic),
    Genre("talk", R.string.g_talk, Icons.Filled.Mic),
    Genre("sports", R.string.g_sports, Icons.Filled.SportsSoccer),
    Genre("electronic", R.string.g_electronic, Icons.Filled.GraphicEq),
    Genre("folk", R.string.g_folk, Icons.Filled.Public),
    Genre("quran", R.string.g_quran, Icons.Filled.MenuBook),
    Genre("oldies", R.string.g_oldies, Icons.Filled.History),
    Genre("chillout", R.string.g_chillout, Icons.Filled.Spa),
)

@Composable
fun GenreTile(genre: Genre, modifier: Modifier = Modifier, onOpen: (Genre, String) -> Unit) {
    val label = stringResource(genre.label)
    Surface(
        onClick = { onOpen(genre, label) },
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = modifier.height(56.dp),
    ) {
        Row(Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(genre.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text(label, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun GenreRail(onOpen: (Genre, String) -> Unit) {
    LazyHorizontalGrid(
        rows = GridCells.Fixed(2),
        modifier = Modifier.fillMaxWidth().height(124.dp),
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(Genres, key = { it.tag }) { g -> GenreTile(g, Modifier.width(158.dp), onOpen) }
    }
}

// ---------- Structure ----------

@Composable
fun ScreenHeader(title: String, onBack: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(64.dp)
            .padding(start = if (onBack == null) 20.dp else 4.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
            }
        }
        Text(
            title,
            style = if (onBack == null) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        trailing()
    }
}

@Composable
fun SectionHeader(title: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 8.dp, top = 22.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
fun MessageBox(icon: ImageVector, text: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(12.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(14.dp))
            FilledTonalButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
fun LoadingBox(height: Dp = 160.dp) {
    Box(Modifier.fillMaxWidth().height(height), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(strokeWidth = 3.dp)
    }
}

@Composable
fun <T> LoadContent(handle: LoadHandle<T>, loadingHeight: Dp = 160.dp, content: @Composable (T) -> Unit) {
    when (val s = handle.state) {
        is Load.Loading -> LoadingBox(loadingHeight)
        is Load.Fail -> MessageBox(
            Icons.Filled.CloudOff,
            stringResource(R.string.error_load),
            stringResource(R.string.retry),
            handle.retry,
        )
        is Load.Ok -> content(s.value)
    }
}

// ---------- Player bits ----------

@Composable
fun playerStatus(ui: PlayerUi): String = when {
    ui.error == PlayError.NETWORK -> stringResource(R.string.err_network)
    ui.error == PlayError.UNAVAILABLE -> stringResource(R.string.err_unavailable)
    ui.error == PlayError.FORMAT -> stringResource(R.string.err_format)
    ui.error == PlayError.OTHER -> stringResource(R.string.err_other)
    ui.isBuffering -> stringResource(R.string.status_connecting)
    ui.isPlaying -> stringResource(R.string.status_live)
    else -> stringResource(R.string.status_paused)
}

@Composable
fun EqualizerBars(active: Boolean, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    val transition = rememberInfiniteTransition(label = "eq")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "eqPhase",
    )
    Canvas(modifier) {
        val bars = 4
        val w = size.width / (bars * 2 - 1)
        for (i in 0 until bars) {
            val level = if (active) 0.3f + 0.7f * abs(sin(phase + i * 1.3f)) else 0.25f
            val bh = size.height * level
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2 * w, size.height - bh),
                size = Size(w, bh),
                cornerRadius = CornerRadius(w / 2, w / 2),
            )
        }
    }
}

/** The app's signature: an analog tuning scale whose needle swings to each station. */
@Composable
fun TuningDial(seed: String, active: Boolean, modifier: Modifier = Modifier) {
    val target = remember(seed) { ((seed.hashCode() and 0x7fffffff) % 1000) / 1000f * 0.8f + 0.1f }
    val pos by animateFloatAsState(target, spring(dampingRatio = 0.55f, stiffness = 60f), label = "needle")
    val glow by animateFloatAsState(if (active) 0.32f else 0.1f, label = "glow")
    val tick = MaterialTheme.colorScheme.onSurfaceVariant
    val amber = MaterialTheme.colorScheme.primary
    Canvas(modifier.fillMaxWidth().height(52.dp)) {
        val count = 61
        val inset = 2.dp.toPx()
        val step = (size.width - inset * 2) / (count - 1)
        for (i in 0 until count) {
            val x = inset + i * step
            val major = i % 10 == 0
            val mid = i % 5 == 0
            val h = when {
                major -> size.height * 0.55f
                mid -> size.height * 0.38f
                else -> size.height * 0.22f
            }
            drawLine(
                color = tick.copy(alpha = if (major) 0.85f else 0.4f),
                start = Offset(x, size.height - h),
                end = Offset(x, size.height),
                strokeWidth = if (major) 2.dp.toPx() else 1.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
        val nx = inset + (size.width - inset * 2) * pos
        drawCircle(amber.copy(alpha = glow), radius = size.height * 0.5f, center = Offset(nx, size.height * 0.55f))
        drawLine(amber, Offset(nx, 0f), Offset(nx, size.height), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
    }
}

@Composable
fun MiniPlayer(ui: PlayerUi, onOpen: () -> Unit, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val s = ui.station ?: return
    Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh, modifier = modifier) {
        Column {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        if (ui.isPlaying) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.outlineVariant
                    )
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpen)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StationArt(s.name, s.favicon, 44.dp, corner = 12.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        playerStatus(ui),
                        style = MaterialTheme.typography.bodySmall,
                        color = if (ui.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.width(8.dp))
                if (ui.isBuffering) {
                    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                    }
                } else {
                    FilledIconButton(onClick = onToggle) {
                        Icon(
                            if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(if (ui.isPlaying) R.string.pause else R.string.play),
                        )
                    }
                }
            }
        }
    }
}
