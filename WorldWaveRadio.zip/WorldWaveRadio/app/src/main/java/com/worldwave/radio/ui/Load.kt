package com.worldwave.radio.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.worldwave.radio.RadioApp
import kotlinx.coroutines.CancellationException
import java.util.Locale

sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Ok<out T>(val value: T) : Load<T>
    data class Fail(val error: Throwable) : Load<Nothing>
}

class LoadHandle<T>(val state: Load<T>, val retry: () -> Unit)

/** Runs [loader] once per key set, with a retry hook. Repository caching keeps re-entry cheap. */
@Composable
fun <T> loadable(vararg keys: Any?, loader: suspend () -> T): LoadHandle<T> {
    var attempt by remember(*keys) { mutableIntStateOf(0) }
    val state = produceState<Load<T>>(Load.Loading, *keys, attempt) {
        value = Load.Loading
        value = try {
            Load.Ok(loader())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Load.Fail(e)
        }
    }
    return LoadHandle(state.value) { attempt++ }
}

@Composable
fun app(): RadioApp = LocalContext.current.applicationContext as RadioApp

@Composable
fun currentLocale(): Locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()

fun <T> Load<T>.valueOrNull(): T? = if (this is Load.Ok) value else null
