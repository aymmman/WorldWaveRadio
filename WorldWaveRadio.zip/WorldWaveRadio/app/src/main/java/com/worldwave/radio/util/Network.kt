package com.worldwave.radio.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

enum class NetType { NONE, UNMETERED, METERED }

fun currentNetwork(context: Context): NetType {
    val cm = context.getSystemService(ConnectivityManager::class.java) ?: return NetType.NONE
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return NetType.NONE
    if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return NetType.NONE
    return if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) NetType.UNMETERED
    else NetType.METERED
}
