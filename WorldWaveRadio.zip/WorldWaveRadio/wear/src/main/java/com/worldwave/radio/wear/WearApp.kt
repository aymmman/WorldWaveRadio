package com.worldwave.radio.wear

import android.app.Application
import android.content.Context
import com.worldwave.radio.RadioHost
import com.worldwave.radio.data.Prefs
import com.worldwave.radio.data.RadioRepository
import com.worldwave.radio.playback.PlayerConnection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PlayTarget { WATCH, PHONE }

class WearApp : Application(), RadioHost {
    override lateinit var prefs: Prefs
        private set
    lateinit var repo: RadioRepository
        private set
    lateinit var player: PlayerConnection
        private set
    lateinit var link: PhoneLink
        private set

    private val _target = MutableStateFlow(PlayTarget.WATCH)
    val target: StateFlow<PlayTarget> = _target.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        repo = RadioRepository(this)
        player = PlayerConnection(this, prefs, repo, WearRadioService::class.java)
        link = PhoneLink(this).also { it.start() }
        val saved = getSharedPreferences("wear", Context.MODE_PRIVATE).getString("target", null)
        _target.value = if (saved == PlayTarget.PHONE.name) PlayTarget.PHONE else PlayTarget.WATCH
    }

    fun setTarget(t: PlayTarget) {
        _target.value = t
        getSharedPreferences("wear", Context.MODE_PRIVATE).edit().putString("target", t.name).apply()
    }
}
