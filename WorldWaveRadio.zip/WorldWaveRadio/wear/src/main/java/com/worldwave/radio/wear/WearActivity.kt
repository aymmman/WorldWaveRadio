package com.worldwave.radio.wear

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.worldwave.radio.wear.ui.WearRoot

class WearActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as WearApp
        setContent { WearRoot(app) }
    }

    override fun onStart() {
        super.onStart()
        val app = application as WearApp
        app.player.connect()
        app.link.refresh()
    }
}
