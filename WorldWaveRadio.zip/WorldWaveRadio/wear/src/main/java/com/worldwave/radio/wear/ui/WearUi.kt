package com.worldwave.radio.wear.ui

import android.content.Context
import android.media.AudioManager
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Watch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.wear.compose.foundation.lazy.AutoCenteringParams
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.ScalingLazyListScope
import androidx.wear.compose.foundation.lazy.items
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Button
import androidx.wear.compose.material.ButtonDefaults
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.CircularProgressIndicator
import androidx.wear.compose.material.Colors
import androidx.wear.compose.material.Icon
import androidx.wear.compose.material.ListHeader
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.PositionIndicator
import androidx.wear.compose.material.Scaffold
import androidx.wear.compose.material.Text
import androidx.wear.compose.material.TimeText
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import coil.compose.AsyncImage
import com.worldwave.radio.WearPaths
import com.worldwave.radio.data.Station
import com.worldwave.radio.data.StationQuery
import com.worldwave.radio.playback.PlayerUi
import com.worldwave.radio.util.countryName
import com.worldwave.radio.util.flagEmoji
import com.worldwave.radio.util.initials
import com.worldwave.radio.util.isPlayableUrl
import com.worldwave.radio.wear.PlayTarget
import com.worldwave.radio.wear.R
import com.worldwave.radio.wear.WearApp
import kotlinx.coroutines.CancellationException
import java.util.Locale

// ---------- Theme ----------

private val WearColors = Colors(
    primary = Color(0xFFFFB23E),
    primaryVariant = Color(0xFFC77700),
    secondary = Color(0xFF6FD3FF),
    secondaryVariant = Color(0xFF1B3B66),
    background = Color.Black,
    surface = Color(0xFF1A2550),
    error = Color(0xFFFF8A80),
    onPrimary = Color(0xFF2A1700),
    onSecondary = Color(0xFF00344A),
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Color(0xFFA3ACD0),
    onError = Color.Black,
)

// ---------- Small helpers ----------

private sealed interface WLoad<out T> {
    data object Loading : WLoad<Nothing>
    data class Ok<out T>(val value: T) : WLoad<T>
    data object Fail : WLoad<Nothing>
}

@Composable
private fun <T> wearLoad(vararg keys: Any?, loader: suspend () -> T): Pair<WLoad<T>, () -> Unit> {
    var attempt by remember(*keys) { mutableIntStateOf(0) }
    val state = produceState<WLoad<T>>(WLoad.Loading, *keys, attempt) {
        value = WLoad.Loading
        value = try {
            WLoad.Ok(loader())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            WLoad.Fail
        }
    }
    return state.value to { attempt++ }
}

@Composable
private fun locale(): Locale = LocalConfiguration.current.locales[0] ?: Locale.getDefault()

private fun subtitle(s: Station, locale: Locale): String {
    val country = countryName(s.countryCode, s.country, locale)
    val flag = if (s.countryCode.length == 2) flagEmoji(s.countryCode) + " " else ""
    return (flag + country).ifBlank { s.codec }
}

private fun adjustVolume(context: Context, direction: Int) {
    val am = context.getSystemService(AudioManager::class.java) ?: return
    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
}

@Composable
private fun WearList(content: ScalingLazyListScope.() -> Unit) {
    val state = rememberScalingLazyListState()
    Scaffold(
        timeText = { TimeText() },
        positionIndicator = { PositionIndicator(scalingLazyListState = state) },
    ) {
        ScalingLazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = state,
            autoCentering = AutoCenteringParams(itemIndex = 0),
            content = content,
        )
    }
}

@Composable
private fun StationIcon(station: Station) {
    Box(
        Modifier
            .size(ChipDefaults.LargeIconSize)
            .clip(CircleShape)
            .background(MaterialTheme.colors.surface),
        contentAlignment = Alignment.Center,
    ) {
        Text(initials(station.name), style = MaterialTheme.typography.caption2, maxLines = 1)
        if (isPlayableUrl(station.favicon)) {
            AsyncImage(
                model = station.favicon,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

@Composable
private fun NavChip(label: String, icon: ImageVector, secondary: String? = null, primary: Boolean = false, onClick: () -> Unit) {
    Chip(
        onClick = onClick,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        secondaryLabel = if (secondary != null) {
            { Text(secondary, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        } else null,
        icon = { Icon(icon, contentDescription = null) },
        colors = if (primary) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun StationChip(station: Station, locale: Locale, onClick: () -> Unit) {
    Chip(
        onClick = onClick,
        label = { Text(station.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        secondaryLabel = { Text(subtitle(station, locale), maxLines = 1, overflow = TextOverflow.Ellipsis) },
        icon = { StationIcon(station) },
        colors = ChipDefaults.secondaryChipColors(),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun Message(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.caption1,
        color = MaterialTheme.colors.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
    )
}

private data class WearGenre(val tag: String, @StringRes val label: Int)

private val wearGenres = listOf(
    WearGenre("news", R.string.g_news),
    WearGenre("quran", R.string.g_quran),
    WearGenre("pop", R.string.g_pop),
    WearGenre("rock", R.string.g_rock),
    WearGenre("jazz", R.string.g_jazz),
    WearGenre("classical", R.string.g_classical),
    WearGenre("talk", R.string.g_talk),
    WearGenre("sports", R.string.g_sports),
    WearGenre("chillout", R.string.g_chillout),
)

// ---------- Root ----------

@Composable
fun WearRoot(app: WearApp) {
    val nav = rememberSwipeDismissableNavController()
    MaterialTheme(colors = WearColors) {
        SwipeDismissableNavHost(navController = nav, startDestination = "home") {
            composable("home") { HomeScreen(app, nav) }
            composable("countries") { CountriesScreen(app, nav) }
            composable("list/{kind}/{value}") { entry ->
                StationListScreen(
                    app = app,
                    nav = nav,
                    kind = entry.arguments?.getString("kind") ?: "top",
                    value = entry.arguments?.getString("value") ?: "all",
                )
            }
            composable("player") { WatchPlayerScreen(app) }
            composable("remote") { PhoneRemoteScreen(app) }
        }
    }
}

// ---------- Home ----------

@Composable
private fun HomeScreen(app: WearApp, nav: NavHostController) {
    val target by app.target.collectAsStateWithLifecycle()
    val ui by app.player.state.collectAsStateWithLifecycle()
    val phone by app.link.state.collectAsStateWithLifecycle()

    WearList {
        item { ListHeader { Text(stringResource(R.string.app_name), color = MaterialTheme.colors.primary) } }
        item {
            NavChip(
                label = stringResource(R.string.play_on),
                icon = if (target == PlayTarget.WATCH) Icons.Filled.Watch else Icons.Filled.PhoneAndroid,
                secondary = stringResource(if (target == PlayTarget.WATCH) R.string.target_watch else R.string.target_phone),
            ) {
                app.setTarget(if (target == PlayTarget.WATCH) PlayTarget.PHONE else PlayTarget.WATCH)
            }
        }
        val watchStation = ui.station
        if (watchStation != null) {
            item {
                NavChip(
                    label = stringResource(R.string.now_playing),
                    icon = Icons.Filled.GraphicEq,
                    secondary = watchStation.name,
                    primary = true,
                ) { nav.navigate("player") }
            }
        }
        item {
            val p = phone
            NavChip(
                label = stringResource(R.string.phone),
                icon = Icons.Filled.PhoneAndroid,
                secondary = if (p != null && p.name.isNotBlank()) p.name else stringResource(R.string.phone_idle),
            ) { nav.navigate("remote") }
        }
        item { NavChip(stringResource(R.string.favorites), Icons.Filled.Favorite) { nav.navigate("list/fav/all") } }
        item { NavChip(stringResource(R.string.popular), Icons.Filled.TrendingUp) { nav.navigate("list/top/all") } }
        item { NavChip(stringResource(R.string.arabic), Icons.Filled.Public) { nav.navigate("list/language/arabic") } }
        item { NavChip(stringResource(R.string.countries), Icons.Filled.Public) { nav.navigate("countries") } }
        item { NavChip(stringResource(R.string.recent), Icons.Filled.History) { nav.navigate("list/recent/all") } }
        item { ListHeader { Text(stringResource(R.string.genres)) } }
        items(wearGenres) { g ->
            Chip(
                onClick = { nav.navigate("list/tag/${g.tag}") },
                label = { Text(stringResource(g.label)) },
                colors = ChipDefaults.secondaryChipColors(),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ---------- Lists ----------

@Composable
private fun CountriesScreen(app: WearApp, nav: NavHostController) {
    val loc = locale()
    val (state, retry) = wearLoad("countries") { app.repo.countries() }
    WearList {
        item { ListHeader { Text(stringResource(R.string.countries)) } }
        when (state) {
            is WLoad.Loading -> item { CircularProgressIndicator() }
            is WLoad.Fail -> item {
                Chip(onClick = retry, label = { Text(stringResource(R.string.retry)) }, modifier = Modifier.fillMaxWidth())
            }
            is WLoad.Ok -> items(state.value.take(80)) { c ->
                Chip(
                    onClick = { nav.navigate("list/country/${c.code}") },
                    label = { Text(flagEmoji(c.code) + "  " + countryName(c.code, c.name, loc), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun StationListScreen(app: WearApp, nav: NavHostController, kind: String, value: String) {
    val loc = locale()
    val target by app.target.collectAsStateWithLifecycle()
    val phoneFavorites by app.link.favorites.collectAsStateWithLifecycle()
    val history by app.prefs.history.collectAsStateWithLifecycle()
    val hidden by app.prefs.hidden.collectAsStateWithLifecycle()

    val (state, retry) = wearLoad(kind, value) {
        when (kind) {
            "fav", "recent" -> emptyList()
            "top" -> app.repo.top(30)
            "language" -> app.repo.search(StationQuery(language = value), 0, 40).stations
            "country" -> app.repo.search(StationQuery(countryCode = value), 0, 40).stations
            else -> app.repo.search(StationQuery(tag = value), 0, 40).stations
        }
    }
    val stations: List<Station>? = when (kind) {
        "fav" -> phoneFavorites
        "recent" -> history
        else -> (state as? WLoad.Ok<List<Station>>)?.value
    }?.filter { it.uuid !in hidden }

    val onPick: (Station, List<Station>) -> Unit = { s, list ->
        if (target == PlayTarget.WATCH) {
            app.player.play(s, list)
            nav.navigate("player")
        } else {
            app.link.playOnPhone(s)
            nav.navigate("remote")
        }
    }

    WearList {
        item {
            ListHeader {
                Text(stringResource(if (target == PlayTarget.WATCH) R.string.target_watch else R.string.target_phone))
            }
        }
        when {
            stations != null && stations.isEmpty() -> item {
                Message(stringResource(if (kind == "fav") R.string.favorites_empty else R.string.empty))
            }
            stations != null -> items(stations) { s -> StationChip(s, loc) { onPick(s, stations) } }
            state is WLoad.Fail -> item {
                Chip(onClick = retry, label = { Text(stringResource(R.string.retry)) }, modifier = Modifier.fillMaxWidth())
            }
            else -> item { CircularProgressIndicator() }
        }
    }
}

// ---------- Players ----------

@Composable
private fun watchStatus(ui: PlayerUi): String = when {
    ui.error != null -> stringResource(R.string.status_error)
    ui.isBuffering -> stringResource(R.string.status_connecting)
    ui.isPlaying -> stringResource(R.string.status_live)
    else -> stringResource(R.string.status_paused)
}

@Composable
private fun ControlsLayout(
    title: String,
    status: String,
    hint: String?,
    playing: Boolean,
    busy: Boolean,
    onPrevious: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onVolumeDown: () -> Unit,
    onStop: () -> Unit,
    onVolumeUp: () -> Unit,
) {
    Scaffold(timeText = { TimeText() }) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Spacer(Modifier.height(18.dp))
            Text(
                title,
                style = MaterialTheme.typography.title3,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                status,
                style = MaterialTheme.typography.caption2,
                color = MaterialTheme.colors.primary,
                textAlign = TextAlign.Center,
                maxLines = 1,
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPrevious, colors = ButtonDefaults.secondaryButtonColors(), modifier = Modifier.size(ButtonDefaults.SmallButtonSize)) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = stringResource(R.string.previous))
                }
                Button(onClick = onToggle, modifier = Modifier.size(ButtonDefaults.LargeButtonSize)) {
                    if (busy) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), indicatorColor = MaterialTheme.colors.onPrimary)
                    } else {
                        Icon(
                            if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(if (playing) R.string.pause else R.string.play),
                            modifier = Modifier.size(30.dp),
                        )
                    }
                }
                Button(onClick = onNext, colors = ButtonDefaults.secondaryButtonColors(), modifier = Modifier.size(ButtonDefaults.SmallButtonSize)) {
                    Icon(Icons.Filled.SkipNext, contentDescription = stringResource(R.string.next))
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onVolumeDown, colors = ButtonDefaults.secondaryButtonColors(), modifier = Modifier.size(ButtonDefaults.SmallButtonSize)) {
                    Icon(Icons.Filled.VolumeDown, contentDescription = stringResource(R.string.volume_down))
                }
                Button(onClick = onStop, colors = ButtonDefaults.secondaryButtonColors(), modifier = Modifier.size(ButtonDefaults.SmallButtonSize)) {
                    Icon(Icons.Filled.Stop, contentDescription = stringResource(R.string.stop))
                }
                Button(onClick = onVolumeUp, colors = ButtonDefaults.secondaryButtonColors(), modifier = Modifier.size(ButtonDefaults.SmallButtonSize)) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = stringResource(R.string.volume_up))
                }
            }
            if (hint != null) {
                Text(
                    hint,
                    style = MaterialTheme.typography.caption3,
                    color = MaterialTheme.colors.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun WatchPlayerScreen(app: WearApp) {
    val context = LocalContext.current
    val ui by app.player.state.collectAsStateWithLifecycle()
    ControlsLayout(
        title = ui.station?.name ?: stringResource(R.string.app_name),
        status = watchStatus(ui),
        hint = if (!ui.isPlaying) stringResource(R.string.headphones_hint) else null,
        playing = ui.isPlaying,
        busy = ui.isBuffering,
        onPrevious = { app.player.previous() },
        onToggle = { if (ui.error != null) app.player.retry() else app.player.toggle() },
        onNext = { app.player.next() },
        onVolumeDown = { adjustVolume(context, AudioManager.ADJUST_LOWER) },
        onStop = { app.player.stop() },
        onVolumeUp = { adjustVolume(context, AudioManager.ADJUST_RAISE) },
    )
}

@Composable
private fun PhoneRemoteScreen(app: WearApp) {
    val phone by app.link.state.collectAsStateWithLifecycle()
    val connected by app.link.connected.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { app.link.send(WearPaths.SYNC) }

    val p = phone
    val status = when {
        connected == false -> stringResource(R.string.phone_not_found)
        p == null || p.name.isBlank() -> stringResource(R.string.phone_idle)
        p.error -> stringResource(R.string.status_error)
        p.buffering -> stringResource(R.string.status_connecting)
        p.playing -> stringResource(R.string.status_live)
        else -> stringResource(R.string.status_paused)
    }
    ControlsLayout(
        title = p?.name?.ifBlank { null } ?: stringResource(R.string.target_phone),
        status = status,
        hint = null,
        playing = p?.playing == true,
        busy = p?.buffering == true,
        onPrevious = { app.link.send(WearPaths.PREVIOUS) },
        onToggle = { app.link.send(WearPaths.TOGGLE) },
        onNext = { app.link.send(WearPaths.NEXT) },
        onVolumeDown = { app.link.send(WearPaths.VOLUME_DOWN) },
        onStop = { app.link.send(WearPaths.STOP) },
        onVolumeUp = { app.link.send(WearPaths.VOLUME_UP) },
    )
}
