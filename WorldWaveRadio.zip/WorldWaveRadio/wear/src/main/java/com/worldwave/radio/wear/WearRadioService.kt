package com.worldwave.radio.wear

import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.worldwave.radio.playback.BaseRadioService

/**
 * Watch playback. Wear OS routes traffic through the phone's Bluetooth link by default,
 * which is too slow for streaming, so while playing we ask for Wi-Fi or LTE directly.
 */
class WearRadioService : BaseRadioService() {
    private var callback: ConnectivityManager.NetworkCallback? = null

    override fun launchIntent(): Intent =
        Intent(this, WearActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean) {
        if (playWhenReady) requestFastNetwork() else releaseNetwork()
    }

    private fun requestFastNetwork() {
        if (callback != null) return
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                cm.bindProcessToNetwork(network)
            }

            override fun onLost(network: Network) {
                cm.bindProcessToNetwork(null)
            }
        }
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
            .build()
        try {
            cm.requestNetwork(request, cb)
            callback = cb
        } catch (e: Exception) {
            // Fall back to whatever network the watch already has.
        }
    }

    private fun releaseNetwork() {
        val cb = callback ?: return
        callback = null
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        try {
            cm.unregisterNetworkCallback(cb)
        } catch (e: Exception) {
            // Already gone.
        }
        cm.bindProcessToNetwork(null)
    }

    override fun onDestroy() {
        releaseNetwork()
        super.onDestroy()
    }
}
