package com.worldwave.radio.wear

import android.content.Context
import com.google.android.gms.wearable.DataClient
import com.google.android.gms.wearable.DataEvent
import com.google.android.gms.wearable.DataItem
import com.google.android.gms.wearable.DataMapItem
import com.google.android.gms.wearable.Wearable
import com.worldwave.radio.WearPaths
import com.worldwave.radio.data.Station
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONArray

data class PhoneState(
    val uuid: String,
    val name: String,
    val country: String,
    val favicon: String,
    val playing: Boolean,
    val buffering: Boolean,
    val error: Boolean,
)

/** Watch side of the phone link: reads what the phone plays and sends it commands. */
class PhoneLink(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _state = MutableStateFlow<PhoneState?>(null)
    val state: StateFlow<PhoneState?> = _state.asStateFlow()

    private val _favorites = MutableStateFlow<List<Station>>(emptyList())
    val favorites: StateFlow<List<Station>> = _favorites.asStateFlow()

    private val _connected = MutableStateFlow<Boolean?>(null)
    val connected: StateFlow<Boolean?> = _connected.asStateFlow()

    private val listener = DataClient.OnDataChangedListener { events ->
        events.forEach { e -> if (e.type == DataEvent.TYPE_CHANGED) handle(e.dataItem) }
        events.release()
    }

    fun start() {
        try {
            Wearable.getDataClient(context).addListener(listener)
        } catch (e: Exception) {
            // Wear services unavailable.
        }
        refresh()
    }

    fun refresh() {
        scope.launch {
            try {
                val items = Wearable.getDataClient(context).dataItems.await()
                items.forEach { handle(it) }
                items.release()
            } catch (e: Exception) {
                // Nothing synced yet.
            }
            checkConnection()
        }
    }

    suspend fun checkConnection(): Boolean {
        val ok = try {
            Wearable.getNodeClient(context).connectedNodes.await().isNotEmpty()
        } catch (e: Exception) {
            false
        }
        _connected.value = ok
        return ok
    }

    private fun handle(item: DataItem) {
        val map = try {
            DataMapItem.fromDataItem(item).dataMap
        } catch (e: Exception) {
            return
        }
        when (item.uri.path) {
            WearPaths.STATE -> _state.value = PhoneState(
                uuid = map.getString("uuid") ?: "",
                name = map.getString("name") ?: "",
                country = map.getString("country") ?: "",
                favicon = map.getString("favicon") ?: "",
                playing = map.getBoolean("playing"),
                buffering = map.getBoolean("buffering"),
                error = map.getBoolean("error"),
            )
            WearPaths.FAVORITES -> _favorites.value = parseStations(map.getString("json") ?: "[]")
        }
    }

    private fun parseStations(json: String): List<Station> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.let { Station.fromJson(it) } }
    } catch (e: Exception) {
        emptyList()
    }

    fun send(path: String, payload: ByteArray = ByteArray(0)) {
        scope.launch {
            try {
                val nodes = Wearable.getNodeClient(context).connectedNodes.await()
                _connected.value = nodes.isNotEmpty()
                val messages = Wearable.getMessageClient(context)
                nodes.forEach { messages.sendMessage(it.id, path, payload).await() }
            } catch (e: Exception) {
                _connected.value = false
            }
        }
    }

    fun playOnPhone(s: Station) = send(WearPaths.PLAY, s.toJson().toString().toByteArray(Charsets.UTF_8))
}
