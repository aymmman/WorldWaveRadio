# WorldWave Radio (Android)

Global internet radio app. Kotlin + Jetpack Compose + Media3 (ExoPlayer).
Station directory: Radio Browser public API (community-run, free, no key).

## Build on GitHub (no Android Studio needed)
1. Upload `WorldWaveRadio.zip` to the root of your repo (keep it zipped).
2. Add `.github/workflows/build.yml` at the repo root.
3. Push, open the Actions tab, wait for the green check, download the APK artifact.

## Build locally
Open the folder in Android Studio (Koala or newer), JDK 17, then Run.

## What works in v1.0
- Home: continue listening, recently played, popular now, genres, Arabic radio, countries
- Explore: countries (searchable, localized names, station counts), languages, genres
- Search with debounce, recent searches, matching countries
- Station lists with infinite scroll and sorting (popular, liked, quality, A to Z)
- Player: background playback, lock screen and notification controls, Bluetooth buttons,
  audio focus, unplug-to-pause, HLS support, previous/next through the current list
- Bounded auto-reconnect (3 tries with backoff), fallback to the alternate stream URL,
  recovery when the network comes back, no endless retry loops
- Sleep timer (presets + custom 5 to 180 min) with optional fade-out
- Data: per-session MB estimate from bitrate, lifetime total, Wi-Fi only mode,
  mobile data confirmation with MB/hour
- Favorites, history, hide broken stations, share station
- English + Arabic with full RTL, light/dark/system theme
- Directory cache (memory + disk) with stale fallback when offline

## Not in v1.0 (roadmap)
- Interactive world map (country list covers it for now)
- AdMob + premium (needs consent flow, UMP SDK, Play Billing)
- Crash reporting / analytics (Firebase, opt-in)
- Custom collections, cloud sync, alarm
- iOS (needs a Mac; the Android code is native)

## Testing status
- Unit tests written (data estimate, flags, dedupe). They run in CI but have NOT been executed yet.
- No device testing done yet. See the manual checklist in the chat handover.

## Known limitations
- Some streams are HTTP only, so cleartext traffic is enabled.
- Data usage is an estimate from the reported bitrate.
- Station logos come from broadcasters' own URLs; many are missing or low-res.
- Radio Browser data is crowd-sourced: some metadata is wrong or missing.
