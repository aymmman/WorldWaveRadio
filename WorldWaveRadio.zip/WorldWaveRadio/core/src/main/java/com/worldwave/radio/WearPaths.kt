package com.worldwave.radio

/** Data Layer paths shared by the phone and watch apps. */
object WearPaths {
    const val STATE = "/state"
    const val FAVORITES = "/favorites"
    const val REMOTE_PREFIX = "/remote"
    const val TOGGLE = "/remote/toggle"
    const val NEXT = "/remote/next"
    const val PREVIOUS = "/remote/previous"
    const val STOP = "/remote/stop"
    const val PLAY = "/remote/play"
    const val VOLUME_UP = "/remote/volume_up"
    const val VOLUME_DOWN = "/remote/volume_down"
    const val SYNC = "/remote/sync"
}
