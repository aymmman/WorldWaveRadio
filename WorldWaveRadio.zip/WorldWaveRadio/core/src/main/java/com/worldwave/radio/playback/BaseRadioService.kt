package com.worldwave.radio.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.worldwave.radio.RadioHost

/**
 * Shared background playback service for phone and watch. Media3 provides the media
 * notification, lock screen / watch media controls, Bluetooth buttons and audio focus.
 * We add bounded reconnects and a fallback stream URL.
 */
@OptIn(UnstableApi::class)
abstract class BaseRadioService : MediaSessionService() {
    private var session: MediaSession? = null
    private val handler = Handler(Looper.getMainLooper())
    private var retries = 0
    private var currentId: String? = null
    private var fallbackTriedFor: String? = null
    private var readyAt = 0L

    /** Activity opened when the user taps the media notification. */
    protected abstract fun launchIntent(): Intent

    /** Platform tweaks, e.g. the watch requires headphones before playing. */
    protected open fun customize(builder: ExoPlayer.Builder) {}

    protected open fun onPlayWhenReadyChanged(playWhenReady: Boolean) {}

    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 2_500, 5_000)
            .build()
        val builder = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setLoadControl(loadControl)
        customize(builder)
        val player = builder.build()

        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (mediaItem?.mediaId != currentId) {
                    currentId = mediaItem?.mediaId
                    retries = 0
                    fallbackTriedFor = null
                    handler.removeCallbacksAndMessages(null)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) readyAt = SystemClock.elapsedRealtime()
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                this@BaseRadioService.onPlayWhenReadyChanged(playWhenReady)
            }

            override fun onPlayerError(error: PlaybackException) = handleError(player, error)
        })

        val openApp = PendingIntent.getActivity(
            this, 0, launchIntent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        session = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .setCallback(object : MediaSession.Callback {
                override fun onAddMediaItems(
                    mediaSession: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    mediaItems: MutableList<MediaItem>,
                ): ListenableFuture<MutableList<MediaItem>> =
                    Futures.immediateFuture(mediaItems.map { resolve(it) }.toMutableList())
            })
            .build()
    }

    private fun handleError(player: ExoPlayer, error: PlaybackException) {
        val item = player.currentMediaItem ?: return
        val now = SystemClock.elapsedRealtime()
        // A stream that played fine for 30s+ earns a fresh set of retries.
        if (readyAt > 0 && now - readyAt > 30_000) retries = 0
        readyAt = 0

        val code = error.errorCode
        val gone = code == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ||
            code == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND
        val recoverable = !gone && (code in 2000..2999 ||
            code == PlaybackException.ERROR_CODE_TIMEOUT ||
            code == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW)
        val autoReconnect = (application as? RadioHost)?.prefs?.settings?.value?.autoReconnect ?: true

        if (autoReconnect && recoverable && retries < MAX_RETRIES) {
            retries++
            val delayMs = 1_500L shl (retries - 1)
            handler.postDelayed({
                if (player.playerError != null && player.playWhenReady) {
                    player.seekToDefaultPosition()
                    player.prepare()
                }
            }, delayMs)
            return
        }

        val fallback = item.requestMetadata.extras?.getString(EXTRA_FALLBACK)
        if (!fallback.isNullOrBlank() && fallbackTriedFor != item.mediaId) {
            fallbackTriedFor = item.mediaId
            retries = 0
            val mime = if (fallback.contains(".m3u8", ignoreCase = true)) MimeTypes.APPLICATION_M3U8 else null
            val replaced = item.buildUpon().setUri(fallback).setMimeType(mime).build()
            player.replaceMediaItem(player.currentMediaItemIndex, replaced)
            player.prepare()
        }
        // Otherwise stop here: the UI shows the error, no endless loop.
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_FALLBACK = "fallback_url"
        const val EXTRA_HLS = "hls"
        private const val MAX_RETRIES = 3

        /** Controllers strip stream URIs for safety, so we rebuild them from request metadata. */
        fun resolve(item: MediaItem): MediaItem {
            val uri = item.requestMetadata.mediaUri ?: return item
            val hls = item.requestMetadata.extras?.getBoolean(EXTRA_HLS) == true ||
                uri.toString().contains(".m3u8", ignoreCase = true)
            val builder = item.buildUpon().setUri(uri)
            if (hls) builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            return builder.build()
        }
    }
}
