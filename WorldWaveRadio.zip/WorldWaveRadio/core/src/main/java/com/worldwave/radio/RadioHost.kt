package com.worldwave.radio

import com.worldwave.radio.data.Prefs

/** Implemented by the phone and watch Application classes so shared code can reach settings. */
interface RadioHost {
    val prefs: Prefs
}
