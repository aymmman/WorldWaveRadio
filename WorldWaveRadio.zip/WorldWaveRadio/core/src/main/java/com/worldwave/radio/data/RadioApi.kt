package com.worldwave.radio.data

import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Minimal client for the public Radio Browser API (https://api.radio-browser.info).
 * Discovers mirrors, rotates on failure with bounded retries and backoff, and sends a
 * descriptive User-Agent as the project asks.
 */
class RadioApi {
    private val fallbackHosts = listOf(
        "de1.api.radio-browser.info",
        "de2.api.radio-browser.info",
        "fi1.api.radio-browser.info",
        "nl1.api.radio-browser.info",
        "at1.api.radio-browser.info",
    )
    @Volatile private var hosts: List<String>? = null
    @Volatile private var preferred: String? = null
    private val userAgent = "WorldWaveRadio/1.1"

    fun get(path: String): String {
        val list = hosts()
        val pref = preferred
        val ordered = if (pref != null) listOf(pref) + list.filter { it != pref } else list
        var last: Exception? = null
        for ((i, host) in ordered.take(4).withIndex()) {
            if (i > 0) Thread.sleep(250L shl (i - 1))
            try {
                val body = httpGet("https://$host$path", 12_000)
                preferred = host
                return body
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("No directory server available")
    }

    private fun hosts(): List<String> {
        hosts?.let { return it }
        val discovered = try {
            val arr = JSONArray(httpGet("https://all.api.radio-browser.info/json/servers", 6_000))
            (0 until arr.length())
                .mapNotNull { arr.optJSONObject(it)?.optString("name") }
                .filter { it.endsWith("radio-browser.info") }
                .distinct()
                .shuffled()
        } catch (e: Exception) {
            emptyList()
        }
        val result = (discovered + fallbackHosts.shuffled()).distinct()
        hosts = result
        return result
    }

    private fun httpGet(url: String, timeoutMs: Int): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        conn.setRequestProperty("User-Agent", userAgent)
        conn.setRequestProperty("Accept", "application/json")
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
